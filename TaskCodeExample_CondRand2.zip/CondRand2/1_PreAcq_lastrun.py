﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2023.2.3),
    on December 13, 2023, at 18:01
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, parallel
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# Store info about the experiment session
psychopyVersion = '2023.2.3'
expName = 'PreAcq'  # from the Builder filename that created this script
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date': data.getDateStr(),  # add a simple timestamp
    'expName': expName,
    'psychopyVersion': psychopyVersion,
}


def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # temporarily remove keys which the dialog doesn't need to show
    poppedKeys = {
        'date': expInfo.pop('date', data.getDateStr()),
        'expName': expInfo.pop('expName', expName),
        'psychopyVersion': expInfo.pop('psychopyVersion', psychopyVersion),
    }
    # show participant info dialog
    dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # restore hidden keys
    expInfo.update(poppedKeys)
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\test143user\\Desktop\\Shapes_and_Shocks\\R2\\CB1_Shapes_and_Shocks\\1_PreAcq_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(logging.EXP)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=logging.EXP)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=[1920, 1080], fullscr=True, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height'
        )
        if expInfo is not None:
            # store frame rate of monitor if we can measure it
            expInfo['frameRate'] = win.getActualFrameRate()
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [-1.0000, -1.0000, -1.0000]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    win.mouseVisible = False
    win.hideMessage()
    return win


def setupInputs(expInfo, thisExp, win):
    """
    Setup whatever inputs are available (mouse, keyboard, eyetracker, etc.)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    dict
        Dictionary of input devices by name.
    """
    # --- Setup input devices ---
    inputs = {}
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    eyetracker = None
    
    # create a default keyboard (e.g. to check for escape)
    defaultKeyboard = keyboard.Keyboard(backend='iohub')
    # return inputs dict
    return {
        'ioServer': ioServer,
        'defaultKeyboard': defaultKeyboard,
        'eyetracker': eyetracker,
    }

def pauseExperiment(thisExp, inputs=None, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    inputs : dict
        Dictionary of input devices by name.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # make sure we have a keyboard
        if inputs is None:
            inputs = {
                'defaultKeyboard': keyboard.Keyboard(backend='ioHub')
            }
        # check for quit (typically the Esc key)
        if inputs['defaultKeyboard'].getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win, inputs=inputs)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, inputs=inputs, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, inputs, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    inputs : dict
        Dictionary of input devices by name.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = inputs['ioServer']
    defaultKeyboard = inputs['defaultKeyboard']
    eyetracker = inputs['eyetracker']
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "INSTR" ---
    instruct1 = visual.TextStim(win=win, name='instruct1',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "RATING_INTRO" ---
    instruct1_3 = visual.TextStim(win=win, name='instruct1_3',
        text='RATING PRACTICE\n\nYou will practice using the ratings that we will use in the Main Phase. \n\nWhen you see a shape, please rate:\n\n(i) how much you EXPECT to receive an electric shock, \n\n(ii) how POSITIVE / NEGATIVE you feel, and \n\n(iii) how TENSE / CALM you feel.\n\n\n[PRESS SPACEBAR TO START]',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1_3 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "FILL_EXP" ---
    expect_txt = visual.TextStim(win=win, name='expect_txt',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    star_3 = visual.ImageStim(
        win=win,
        name='star_3', 
        image='stims/CSs/FillerCS_star.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.5, 0.4),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    slider_3 = visual.Slider(win=win, name='slider_3',
        startValue=None, size=(1.0, 0.04), pos=(0, -0.3), units=win.units,
        labels=["yes, definitely expect a shock (100%)","unsure (50%)","no, definitely don't expect a shock (0%)"], ticks=(1, 2, 3, 4, 5), granularity=0.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor=[1.0000, 1.0000, 1.0000], markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.025,
        flip=False, ori=0.0, depth=-2, readOnly=False)
    exp_resp_fill = keyboard.Keyboard()
    expect_rating = visual.ImageStim(
        win=win,
        name='expect_rating', 
        image='stims/ExpectRating/expect.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.2), size=(1.15, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-5.0)
    
    # --- Initialize components for Routine "FILL_VAL" ---
    val_text = visual.TextStim(win=win, name='val_text',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    star = visual.ImageStim(
        win=win,
        name='star', 
        image='stims/CSs/FillerCS_star.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.5, 0.4),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    SAM_val = visual.ImageStim(
        win=win,
        name='SAM_val', 
        image='stims/SAM/valence.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    resp_fill_val = keyboard.Keyboard()
    
    # --- Initialize components for Routine "FILL_ARSL" ---
    text_arsl = visual.TextStim(win=win, name='text_arsl',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    star_2 = visual.ImageStim(
        win=win,
        name='star_2', 
        image='stims/CSs/FillerCS_star.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.5, 0.4),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    SAM_arsl = visual.ImageStim(
        win=win,
        name='SAM_arsl', 
        image='stims/SAM/arousal.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    resp_fill_arsl = keyboard.Keyboard()
    
    # --- Initialize components for Routine "CRC_EXP" ---
    expect_txt_2 = visual.TextStim(win=win, name='expect_txt_2',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    image_4 = visual.ImageStim(
        win=win,
        name='image_4', units='pix', 
        image='stims/CSs/CScrc.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    exp_resp_crc = keyboard.Keyboard()
    expect_rating_2 = visual.ImageStim(
        win=win,
        name='expect_rating_2', 
        image='stims/ExpectRating/expect.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.2), size=(1.15, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-4.0)
    slider = visual.Slider(win=win, name='slider',
        startValue=None, size=(1.0, 0.04), pos=(0, -0.3), units=win.units,
        labels=["yes, definitely expect a shock (100%)","unsure (50%)","no, definitely don't expect a shock (0%)"], ticks=(1, 2, 3, 4, 5), granularity=0.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor=[1.0000, 1.0000, 1.0000], markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.025,
        flip=False, ori=0.0, depth=-5, readOnly=False)
    
    # --- Initialize components for Routine "CRC_VAL" ---
    val_text_2 = visual.TextStim(win=win, name='val_text_2',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_val_2 = visual.ImageStim(
        win=win,
        name='SAM_val_2', 
        image='stims/SAM/valence.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    val_resp_crc = keyboard.Keyboard()
    image = visual.ImageStim(
        win=win,
        name='image', units='pix', 
        image='stims/CSs/CScrc.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "CRC_ARSL" ---
    text_arsl_2 = visual.TextStim(win=win, name='text_arsl_2',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_arsl_2 = visual.ImageStim(
        win=win,
        name='SAM_arsl_2', 
        image='stims/SAM/arousal.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    arsl_resp_crc = keyboard.Keyboard()
    image_2 = visual.ImageStim(
        win=win,
        name='image_2', units='pix', 
        image='stims/CSs/CScrc.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "SQ_EXP" ---
    expect_txt_3 = visual.TextStim(win=win, name='expect_txt_3',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    slider_4 = visual.Slider(win=win, name='slider_4',
        startValue=None, size=(1.0, 0.04), pos=(0, -0.3), units=win.units,
        labels=["yes, definitely expect a shock (100%)","unsure (50%)","no, definitely don't expect a shock (0%)"], ticks=(1, 2, 3, 4, 5), granularity=0.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor=[1.0000, 1.0000, 1.0000], markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.025,
        flip=False, ori=0.0, depth=-1, readOnly=False)
    exp_resp_sq = keyboard.Keyboard()
    expect_rating_3 = visual.ImageStim(
        win=win,
        name='expect_rating_3', 
        image='stims/ExpectRating/expect.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.2), size=(1.15, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    image_sqr = visual.ImageStim(
        win=win,
        name='image_sqr', units='pix', 
        image='stims/CSs/CSsq.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-4.0)
    
    # --- Initialize components for Routine "SQ_VAL" ---
    val_text_3 = visual.TextStim(win=win, name='val_text_3',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_val_3 = visual.ImageStim(
        win=win,
        name='SAM_val_3', 
        image='stims/SAM/valence.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    val_resp_sq = keyboard.Keyboard()
    image_sqr_2 = visual.ImageStim(
        win=win,
        name='image_sqr_2', units='pix', 
        image='stims/CSs/CSsq.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "SQ_ARSL" ---
    image_sqr_3 = visual.ImageStim(
        win=win,
        name='image_sqr_3', units='pix', 
        image='stims/CSs/CSsq.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    text_arsl_3 = visual.TextStim(win=win, name='text_arsl_3',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-1.0);
    SAM_arsl_3 = visual.ImageStim(
        win=win,
        name='SAM_arsl_3', 
        image='stims/SAM/arousal.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    arsl_resp_sq = keyboard.Keyboard()
    
    # --- Initialize components for Routine "INSTR" ---
    instruct1 = visual.TextStim(win=win, name='instruct1',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "US_INTRO" ---
    instruct1_2 = visual.TextStim(win=win, name='instruct1_2',
        text='SHOCK RATING\n\nYou will receive an electric shock. Afterwards, you will be asked to rate how POSITIVE / NEGATIVE and how TENSE / CALM you feel.\n\n[PRESS SPACEBAR TO START]',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1_2 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "US" ---
    p_port = parallel.ParallelPort(address='0xDFF8')
    
    # --- Initialize components for Routine "ITI_3s" ---
    iti_3 = visual.TextStim(win=win, name='iti_3',
        text=None,
        font='Open Sans',
        pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "US_VAL" ---
    val_text_4 = visual.TextStim(win=win, name='val_text_4',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_val_4 = visual.ImageStim(
        win=win,
        name='SAM_val_4', 
        image='stims/SAM/valence.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    val_resp_US = keyboard.Keyboard()
    
    # --- Initialize components for Routine "US_ARSL" ---
    text_arsl_4 = visual.TextStim(win=win, name='text_arsl_4',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    arsl_resp_US = keyboard.Keyboard()
    SAM_arsl_4 = visual.ImageStim(
        win=win,
        name='SAM_arsl_4', 
        image='stims/SAM/arousal.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    
    # --- Initialize components for Routine "INSTR" ---
    instruct1 = visual.TextStim(win=win, name='instruct1',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "DOT_INTRO" ---
    instruct1_4 = visual.TextStim(win=win, name='instruct1_4',
        text='"DOTS" TASK\n\nLook at the dots on the screen and decide whether they are moving to the left (press 1) or to the right (press 2). \n\n[PRESS SPACEBAR TO START]',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1_7 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "DOT_BUFF" ---
    pre_cue = visual.TextStim(win=win, name='pre_cue',
        text='direction?',
        font='Open Sans',
        pos=(0, .4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    dots = visual.DotStim(
        win=win, name='dots',
        nDots=100, dotSize=8.0,
        speed=1.0, dir=1.0, coherence=1.0,
        fieldPos=(0.0, 0.0), fieldSize=0.5, fieldAnchor='center', fieldShape='circle',
        signalDots='same', noiseDots='direction',dotLife=1000.0,
        color=[0.9216, 0.9216, 0.9216], colorSpace='rgb', opacity=None,
        depth=-2.0)
    fixation = visual.TextStim(win=win, name='fixation',
        text='+',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    buff_buttons = visual.TextStim(win=win, name='buff_buttons',
        text=' (1)                (2)\n<--               -->',
        font='Open Sans',
        pos=(0, -.3), height=0.04, wrapWidth=None, ori=0.0, 
        color='DarkGrey', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    buff_resp = keyboard.Keyboard()
    late_buff_response = keyboard.Keyboard()
    
    # --- Initialize components for Routine "ITI_1s" ---
    iti_1s = visual.TextStim(win=win, name='iti_1s',
        text=None,
        font='Open Sans',
        pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "INSTR" ---
    instruct1 = visual.TextStim(win=win, name='instruct1',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ok1 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "BYST_INTRO" ---
    text = visual.TextStim(win=win, name='text',
        text='"seen before?" TASK \n\nNow we will practice the "seen before?" trials that we will use in the Main Phase. \n\nYou will see a series of photographs of an object with a scene background. You must respond whether this object and scene background is something you think you have come across before in typical daily life. (1="yes"; 2="no"). Use the keyboard for your responses.\n\nYou must make your responses as accurately as possible within a few seconds.\n\n\n[PRESS SPACEBAR TO START]',
        font='Open Sans',
        pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    ok1_11 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "BYST_PRAC" ---
    txt = visual.TextStim(win=win, name='txt',
        text='',
        font='Open Sans',
        pos=(0, 0.4), height=.05, wrapWidth=None, ori=0, 
        color='DarkSeaGreen', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    image_3 = visual.ImageStim(
        win=win,
        name='image_3', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=(420,340),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-1.0)
    byst_resp = keyboard.Keyboard()
    buttons_ = visual.TextStim(win=win, name='buttons_',
        text='',
        font='Open Sans',
        pos=(0, -0.3), height=0.04, wrapWidth=None, ori=0.0, 
        color='DarkSeaGreen', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "ITI_1S" ---
    
    # --- Initialize components for Routine "DONE" ---
    PRACTICE_PHASE_COMPLETE__ = visual.TextStim(win=win, name='PRACTICE_PHASE_COMPLETE__',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    
    # create some handy timers
    if globalClock is None:
        globalClock = core.Clock()  # to track the time since experiment started
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6)
    
    # --- Prepare to start Routine "INSTR" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('INSTR.started', globalClock.getTime())
    ok1.keys = []
    ok1.rt = []
    _ok1_allKeys = []
    # keep track of which components have finished
    INSTRComponents = [instruct1, ok1]
    for thisComponent in INSTRComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "INSTR" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1* updates
        
        # if instruct1 is starting this frame...
        if instruct1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1.frameNStart = frameN  # exact frame index
            instruct1.tStart = t  # local t and not account for scr refresh
            instruct1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1.started')
            # update status
            instruct1.status = STARTED
            instruct1.setAutoDraw(True)
        
        # if instruct1 is active this frame...
        if instruct1.status == STARTED:
            # update params
            pass
        
        # *ok1* updates
        waitOnFlip = False
        
        # if ok1 is starting this frame...
        if ok1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1.frameNStart = frameN  # exact frame index
            ok1.tStart = t  # local t and not account for scr refresh
            ok1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1.started')
            # update status
            ok1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1.status == STARTED and not waitOnFlip:
            theseKeys = ok1.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_allKeys.extend(theseKeys)
            if len(_ok1_allKeys):
                ok1.keys = _ok1_allKeys[-1].name  # just the last key pressed
                ok1.rt = _ok1_allKeys[-1].rt
                ok1.duration = _ok1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in INSTRComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "INSTR" ---
    for thisComponent in INSTRComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('INSTR.stopped', globalClock.getTime())
    # check responses
    if ok1.keys in ['', [], None]:  # No response was made
        ok1.keys = None
    thisExp.addData('ok1.keys',ok1.keys)
    if ok1.keys != None:  # we had a response
        thisExp.addData('ok1.rt', ok1.rt)
        thisExp.addData('ok1.duration', ok1.duration)
    thisExp.nextEntry()
    # the Routine "INSTR" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "RATING_INTRO" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('RATING_INTRO.started', globalClock.getTime())
    ok1_3.keys = []
    ok1_3.rt = []
    _ok1_3_allKeys = []
    # keep track of which components have finished
    RATING_INTROComponents = [instruct1_3, ok1_3]
    for thisComponent in RATING_INTROComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "RATING_INTRO" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1_3* updates
        
        # if instruct1_3 is starting this frame...
        if instruct1_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1_3.frameNStart = frameN  # exact frame index
            instruct1_3.tStart = t  # local t and not account for scr refresh
            instruct1_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1_3.started')
            # update status
            instruct1_3.status = STARTED
            instruct1_3.setAutoDraw(True)
        
        # if instruct1_3 is active this frame...
        if instruct1_3.status == STARTED:
            # update params
            pass
        
        # *ok1_3* updates
        waitOnFlip = False
        
        # if ok1_3 is starting this frame...
        if ok1_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1_3.frameNStart = frameN  # exact frame index
            ok1_3.tStart = t  # local t and not account for scr refresh
            ok1_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1_3.started')
            # update status
            ok1_3.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1_3.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1_3.status == STARTED and not waitOnFlip:
            theseKeys = ok1_3.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_3_allKeys.extend(theseKeys)
            if len(_ok1_3_allKeys):
                ok1_3.keys = _ok1_3_allKeys[-1].name  # just the last key pressed
                ok1_3.rt = _ok1_3_allKeys[-1].rt
                ok1_3.duration = _ok1_3_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code_4
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RATING_INTROComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "RATING_INTRO" ---
    for thisComponent in RATING_INTROComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('RATING_INTRO.stopped', globalClock.getTime())
    # check responses
    if ok1_3.keys in ['', [], None]:  # No response was made
        ok1_3.keys = None
    thisExp.addData('ok1_3.keys',ok1_3.keys)
    if ok1_3.keys != None:  # we had a response
        thisExp.addData('ok1_3.rt', ok1_3.rt)
        thisExp.addData('ok1_3.duration', ok1_3.duration)
    thisExp.nextEntry()
    # the Routine "RATING_INTRO" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    RATING_PRAC = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='RATING_PRAC')
    thisExp.addLoop(RATING_PRAC)  # add the loop to the experiment
    thisRATING_PRAC = RATING_PRAC.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisRATING_PRAC.rgb)
    if thisRATING_PRAC != None:
        for paramName in thisRATING_PRAC:
            globals()[paramName] = thisRATING_PRAC[paramName]
    
    for thisRATING_PRAC in RATING_PRAC:
        currentLoop = RATING_PRAC
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisRATING_PRAC.rgb)
        if thisRATING_PRAC != None:
            for paramName in thisRATING_PRAC:
                globals()[paramName] = thisRATING_PRAC[paramName]
        
        # --- Prepare to start Routine "FILL_EXP" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('FILL_EXP.started', globalClock.getTime())
        expect_txt.setText('When you see this shape, \ndo you EXPECT an electric shock? ')
        slider_3.reset()
        exp_resp_fill.keys = []
        exp_resp_fill.rt = []
        _exp_resp_fill_allKeys = []
        # keep track of which components have finished
        FILL_EXPComponents = [expect_txt, star_3, slider_3, exp_resp_fill, expect_rating]
        for thisComponent in FILL_EXPComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "FILL_EXP" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *expect_txt* updates
            
            # if expect_txt is starting this frame...
            if expect_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                expect_txt.frameNStart = frameN  # exact frame index
                expect_txt.tStart = t  # local t and not account for scr refresh
                expect_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(expect_txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'expect_txt.started')
                # update status
                expect_txt.status = STARTED
                expect_txt.setAutoDraw(True)
            
            # if expect_txt is active this frame...
            if expect_txt.status == STARTED:
                # update params
                pass
            
            # *star_3* updates
            
            # if star_3 is starting this frame...
            if star_3.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                star_3.frameNStart = frameN  # exact frame index
                star_3.tStart = t  # local t and not account for scr refresh
                star_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(star_3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'star_3.started')
                # update status
                star_3.status = STARTED
                star_3.setAutoDraw(True)
            
            # if star_3 is active this frame...
            if star_3.status == STARTED:
                # update params
                pass
            
            # *slider_3* updates
            
            # if slider_3 is starting this frame...
            if slider_3.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                slider_3.frameNStart = frameN  # exact frame index
                slider_3.tStart = t  # local t and not account for scr refresh
                slider_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider_3, 'tStartRefresh')  # time at next scr refresh
                # update status
                slider_3.status = STARTED
                slider_3.setAutoDraw(True)
            
            # if slider_3 is active this frame...
            if slider_3.status == STARTED:
                # update params
                pass
            # Run 'Each Frame' code from code_6
            your_mouse = event.Mouse(visible = True)
            
            # *exp_resp_fill* updates
            waitOnFlip = False
            
            # if exp_resp_fill is starting this frame...
            if exp_resp_fill.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                exp_resp_fill.frameNStart = frameN  # exact frame index
                exp_resp_fill.tStart = t  # local t and not account for scr refresh
                exp_resp_fill.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_resp_fill, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'exp_resp_fill.started')
                # update status
                exp_resp_fill.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(exp_resp_fill.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(exp_resp_fill.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if exp_resp_fill.status == STARTED and not waitOnFlip:
                theseKeys = exp_resp_fill.getKeys(keyList=['1','2','3','4','5'], ignoreKeys=["escape"], waitRelease=False)
                _exp_resp_fill_allKeys.extend(theseKeys)
                if len(_exp_resp_fill_allKeys):
                    exp_resp_fill.keys = _exp_resp_fill_allKeys[-1].name  # just the last key pressed
                    exp_resp_fill.rt = _exp_resp_fill_allKeys[-1].rt
                    exp_resp_fill.duration = _exp_resp_fill_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *expect_rating* updates
            
            # if expect_rating is starting this frame...
            if expect_rating.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                expect_rating.frameNStart = frameN  # exact frame index
                expect_rating.tStart = t  # local t and not account for scr refresh
                expect_rating.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(expect_rating, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'expect_rating.started')
                # update status
                expect_rating.status = STARTED
                expect_rating.setAutoDraw(True)
            
            # if expect_rating is active this frame...
            if expect_rating.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FILL_EXPComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "FILL_EXP" ---
        for thisComponent in FILL_EXPComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('FILL_EXP.stopped', globalClock.getTime())
        RATING_PRAC.addData('slider_3.response', slider_3.getRating())
        RATING_PRAC.addData('slider_3.history', slider_3.getHistory())
        # check responses
        if exp_resp_fill.keys in ['', [], None]:  # No response was made
            exp_resp_fill.keys = None
        RATING_PRAC.addData('exp_resp_fill.keys',exp_resp_fill.keys)
        if exp_resp_fill.keys != None:  # we had a response
            RATING_PRAC.addData('exp_resp_fill.rt', exp_resp_fill.rt)
            RATING_PRAC.addData('exp_resp_fill.duration', exp_resp_fill.duration)
        # the Routine "FILL_EXP" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "FILL_VAL" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('FILL_VAL.started', globalClock.getTime())
        val_text.setText('When you see this shape, \nhow POSITIVE / NEGATIVE do you feel? ')
        resp_fill_val.keys = []
        resp_fill_val.rt = []
        _resp_fill_val_allKeys = []
        # keep track of which components have finished
        FILL_VALComponents = [val_text, star, SAM_val, resp_fill_val]
        for thisComponent in FILL_VALComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "FILL_VAL" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *val_text* updates
            
            # if val_text is starting this frame...
            if val_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                val_text.frameNStart = frameN  # exact frame index
                val_text.tStart = t  # local t and not account for scr refresh
                val_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(val_text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'val_text.started')
                # update status
                val_text.status = STARTED
                val_text.setAutoDraw(True)
            
            # if val_text is active this frame...
            if val_text.status == STARTED:
                # update params
                pass
            
            # *star* updates
            
            # if star is starting this frame...
            if star.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                star.frameNStart = frameN  # exact frame index
                star.tStart = t  # local t and not account for scr refresh
                star.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(star, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'star.started')
                # update status
                star.status = STARTED
                star.setAutoDraw(True)
            
            # if star is active this frame...
            if star.status == STARTED:
                # update params
                pass
            
            # *SAM_val* updates
            
            # if SAM_val is starting this frame...
            if SAM_val.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                SAM_val.frameNStart = frameN  # exact frame index
                SAM_val.tStart = t  # local t and not account for scr refresh
                SAM_val.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(SAM_val, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'SAM_val.started')
                # update status
                SAM_val.status = STARTED
                SAM_val.setAutoDraw(True)
            
            # if SAM_val is active this frame...
            if SAM_val.status == STARTED:
                # update params
                pass
            
            # *resp_fill_val* updates
            waitOnFlip = False
            
            # if resp_fill_val is starting this frame...
            if resp_fill_val.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                resp_fill_val.frameNStart = frameN  # exact frame index
                resp_fill_val.tStart = t  # local t and not account for scr refresh
                resp_fill_val.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp_fill_val, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'resp_fill_val.started')
                # update status
                resp_fill_val.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(resp_fill_val.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(resp_fill_val.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if resp_fill_val.status == STARTED and not waitOnFlip:
                theseKeys = resp_fill_val.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                _resp_fill_val_allKeys.extend(theseKeys)
                if len(_resp_fill_val_allKeys):
                    resp_fill_val.keys = _resp_fill_val_allKeys[-1].name  # just the last key pressed
                    resp_fill_val.rt = _resp_fill_val_allKeys[-1].rt
                    resp_fill_val.duration = _resp_fill_val_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FILL_VALComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "FILL_VAL" ---
        for thisComponent in FILL_VALComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('FILL_VAL.stopped', globalClock.getTime())
        # check responses
        if resp_fill_val.keys in ['', [], None]:  # No response was made
            resp_fill_val.keys = None
        RATING_PRAC.addData('resp_fill_val.keys',resp_fill_val.keys)
        if resp_fill_val.keys != None:  # we had a response
            RATING_PRAC.addData('resp_fill_val.rt', resp_fill_val.rt)
            RATING_PRAC.addData('resp_fill_val.duration', resp_fill_val.duration)
        # the Routine "FILL_VAL" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "FILL_ARSL" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('FILL_ARSL.started', globalClock.getTime())
        text_arsl.setText('When you see this shape, \nhow TENSE / CALM do you feel? ')
        resp_fill_arsl.keys = []
        resp_fill_arsl.rt = []
        _resp_fill_arsl_allKeys = []
        # keep track of which components have finished
        FILL_ARSLComponents = [text_arsl, star_2, SAM_arsl, resp_fill_arsl]
        for thisComponent in FILL_ARSLComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "FILL_ARSL" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_arsl* updates
            
            # if text_arsl is starting this frame...
            if text_arsl.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                text_arsl.frameNStart = frameN  # exact frame index
                text_arsl.tStart = t  # local t and not account for scr refresh
                text_arsl.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_arsl, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_arsl.started')
                # update status
                text_arsl.status = STARTED
                text_arsl.setAutoDraw(True)
            
            # if text_arsl is active this frame...
            if text_arsl.status == STARTED:
                # update params
                pass
            
            # *star_2* updates
            
            # if star_2 is starting this frame...
            if star_2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                star_2.frameNStart = frameN  # exact frame index
                star_2.tStart = t  # local t and not account for scr refresh
                star_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(star_2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'star_2.started')
                # update status
                star_2.status = STARTED
                star_2.setAutoDraw(True)
            
            # if star_2 is active this frame...
            if star_2.status == STARTED:
                # update params
                pass
            
            # *SAM_arsl* updates
            
            # if SAM_arsl is starting this frame...
            if SAM_arsl.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                SAM_arsl.frameNStart = frameN  # exact frame index
                SAM_arsl.tStart = t  # local t and not account for scr refresh
                SAM_arsl.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(SAM_arsl, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'SAM_arsl.started')
                # update status
                SAM_arsl.status = STARTED
                SAM_arsl.setAutoDraw(True)
            
            # if SAM_arsl is active this frame...
            if SAM_arsl.status == STARTED:
                # update params
                pass
            
            # *resp_fill_arsl* updates
            waitOnFlip = False
            
            # if resp_fill_arsl is starting this frame...
            if resp_fill_arsl.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                resp_fill_arsl.frameNStart = frameN  # exact frame index
                resp_fill_arsl.tStart = t  # local t and not account for scr refresh
                resp_fill_arsl.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp_fill_arsl, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'resp_fill_arsl.started')
                # update status
                resp_fill_arsl.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(resp_fill_arsl.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(resp_fill_arsl.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if resp_fill_arsl.status == STARTED and not waitOnFlip:
                theseKeys = resp_fill_arsl.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                _resp_fill_arsl_allKeys.extend(theseKeys)
                if len(_resp_fill_arsl_allKeys):
                    resp_fill_arsl.keys = _resp_fill_arsl_allKeys[-1].name  # just the last key pressed
                    resp_fill_arsl.rt = _resp_fill_arsl_allKeys[-1].rt
                    resp_fill_arsl.duration = _resp_fill_arsl_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FILL_ARSLComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "FILL_ARSL" ---
        for thisComponent in FILL_ARSLComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('FILL_ARSL.stopped', globalClock.getTime())
        # check responses
        if resp_fill_arsl.keys in ['', [], None]:  # No response was made
            resp_fill_arsl.keys = None
        RATING_PRAC.addData('resp_fill_arsl.keys',resp_fill_arsl.keys)
        if resp_fill_arsl.keys != None:  # we had a response
            RATING_PRAC.addData('resp_fill_arsl.rt', resp_fill_arsl.rt)
            RATING_PRAC.addData('resp_fill_arsl.duration', resp_fill_arsl.duration)
        # the Routine "FILL_ARSL" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        randomise = data.TrialHandler(nReps=1.0, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='randomise')
        thisExp.addLoop(randomise)  # add the loop to the experiment
        thisRandomise = randomise.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisRandomise.rgb)
        if thisRandomise != None:
            for paramName in thisRandomise:
                globals()[paramName] = thisRandomise[paramName]
        
        for thisRandomise in randomise:
            currentLoop = randomise
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisRandomise.rgb)
            if thisRandomise != None:
                for paramName in thisRandomise:
                    globals()[paramName] = thisRandomise[paramName]
            
            # set up handler to look after randomisation of conditions etc
            trials_2 = data.TrialHandler(nReps=1.0, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=[None],
                seed=None, name='trials_2')
            thisExp.addLoop(trials_2)  # add the loop to the experiment
            thisTrial_2 = trials_2.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
            if thisTrial_2 != None:
                for paramName in thisTrial_2:
                    globals()[paramName] = thisTrial_2[paramName]
            
            for thisTrial_2 in trials_2:
                currentLoop = trials_2
                thisExp.timestampOnFlip(win, 'thisRow.t')
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        inputs=inputs, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                )
                # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
                if thisTrial_2 != None:
                    for paramName in thisTrial_2:
                        globals()[paramName] = thisTrial_2[paramName]
                
                # --- Prepare to start Routine "CRC_EXP" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('CRC_EXP.started', globalClock.getTime())
                expect_txt_2.setText('When you see this shape, \ndo you EXPECT an electric shock? ')
                exp_resp_crc.keys = []
                exp_resp_crc.rt = []
                _exp_resp_crc_allKeys = []
                slider.reset()
                # keep track of which components have finished
                CRC_EXPComponents = [expect_txt_2, image_4, exp_resp_crc, expect_rating_2, slider]
                for thisComponent in CRC_EXPComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "CRC_EXP" ---
                routineForceEnded = not continueRoutine
                while continueRoutine:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *expect_txt_2* updates
                    
                    # if expect_txt_2 is starting this frame...
                    if expect_txt_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                        # keep track of start time/frame for later
                        expect_txt_2.frameNStart = frameN  # exact frame index
                        expect_txt_2.tStart = t  # local t and not account for scr refresh
                        expect_txt_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(expect_txt_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'expect_txt_2.started')
                        # update status
                        expect_txt_2.status = STARTED
                        expect_txt_2.setAutoDraw(True)
                    
                    # if expect_txt_2 is active this frame...
                    if expect_txt_2.status == STARTED:
                        # update params
                        pass
                    
                    # *image_4* updates
                    
                    # if image_4 is starting this frame...
                    if image_4.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                        # keep track of start time/frame for later
                        image_4.frameNStart = frameN  # exact frame index
                        image_4.tStart = t  # local t and not account for scr refresh
                        image_4.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_4.started')
                        # update status
                        image_4.status = STARTED
                        image_4.setAutoDraw(True)
                    
                    # if image_4 is active this frame...
                    if image_4.status == STARTED:
                        # update params
                        pass
                    # Run 'Each Frame' code from code_8
                    your_mouse = event.Mouse(visible = True)
                    
                    # *exp_resp_crc* updates
                    waitOnFlip = False
                    
                    # if exp_resp_crc is starting this frame...
                    if exp_resp_crc.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        exp_resp_crc.frameNStart = frameN  # exact frame index
                        exp_resp_crc.tStart = t  # local t and not account for scr refresh
                        exp_resp_crc.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(exp_resp_crc, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'exp_resp_crc.started')
                        # update status
                        exp_resp_crc.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(exp_resp_crc.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(exp_resp_crc.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    if exp_resp_crc.status == STARTED and not waitOnFlip:
                        theseKeys = exp_resp_crc.getKeys(keyList=['1','2','3','4','5'], ignoreKeys=["escape"], waitRelease=False)
                        _exp_resp_crc_allKeys.extend(theseKeys)
                        if len(_exp_resp_crc_allKeys):
                            exp_resp_crc.keys = _exp_resp_crc_allKeys[-1].name  # just the last key pressed
                            exp_resp_crc.rt = _exp_resp_crc_allKeys[-1].rt
                            exp_resp_crc.duration = _exp_resp_crc_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *expect_rating_2* updates
                    
                    # if expect_rating_2 is starting this frame...
                    if expect_rating_2.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        expect_rating_2.frameNStart = frameN  # exact frame index
                        expect_rating_2.tStart = t  # local t and not account for scr refresh
                        expect_rating_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(expect_rating_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'expect_rating_2.started')
                        # update status
                        expect_rating_2.status = STARTED
                        expect_rating_2.setAutoDraw(True)
                    
                    # if expect_rating_2 is active this frame...
                    if expect_rating_2.status == STARTED:
                        # update params
                        pass
                    
                    # *slider* updates
                    
                    # if slider is starting this frame...
                    if slider.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        slider.frameNStart = frameN  # exact frame index
                        slider.tStart = t  # local t and not account for scr refresh
                        slider.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(slider, 'tStartRefresh')  # time at next scr refresh
                        # update status
                        slider.status = STARTED
                        slider.setAutoDraw(True)
                    
                    # if slider is active this frame...
                    if slider.status == STARTED:
                        # update params
                        pass
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in CRC_EXPComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "CRC_EXP" ---
                for thisComponent in CRC_EXPComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('CRC_EXP.stopped', globalClock.getTime())
                # check responses
                if exp_resp_crc.keys in ['', [], None]:  # No response was made
                    exp_resp_crc.keys = None
                trials_2.addData('exp_resp_crc.keys',exp_resp_crc.keys)
                if exp_resp_crc.keys != None:  # we had a response
                    trials_2.addData('exp_resp_crc.rt', exp_resp_crc.rt)
                    trials_2.addData('exp_resp_crc.duration', exp_resp_crc.duration)
                trials_2.addData('slider.response', slider.getRating())
                trials_2.addData('slider.history', slider.getHistory())
                # the Routine "CRC_EXP" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                
                # --- Prepare to start Routine "CRC_VAL" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('CRC_VAL.started', globalClock.getTime())
                val_text_2.setText('When you see this shape, \nhow POSITIVE / NEGATIVE do you feel? ')
                val_resp_crc.keys = []
                val_resp_crc.rt = []
                _val_resp_crc_allKeys = []
                # keep track of which components have finished
                CRC_VALComponents = [val_text_2, SAM_val_2, val_resp_crc, image]
                for thisComponent in CRC_VALComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "CRC_VAL" ---
                routineForceEnded = not continueRoutine
                while continueRoutine:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *val_text_2* updates
                    
                    # if val_text_2 is starting this frame...
                    if val_text_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                        # keep track of start time/frame for later
                        val_text_2.frameNStart = frameN  # exact frame index
                        val_text_2.tStart = t  # local t and not account for scr refresh
                        val_text_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(val_text_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'val_text_2.started')
                        # update status
                        val_text_2.status = STARTED
                        val_text_2.setAutoDraw(True)
                    
                    # if val_text_2 is active this frame...
                    if val_text_2.status == STARTED:
                        # update params
                        pass
                    
                    # *SAM_val_2* updates
                    
                    # if SAM_val_2 is starting this frame...
                    if SAM_val_2.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        SAM_val_2.frameNStart = frameN  # exact frame index
                        SAM_val_2.tStart = t  # local t and not account for scr refresh
                        SAM_val_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(SAM_val_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'SAM_val_2.started')
                        # update status
                        SAM_val_2.status = STARTED
                        SAM_val_2.setAutoDraw(True)
                    
                    # if SAM_val_2 is active this frame...
                    if SAM_val_2.status == STARTED:
                        # update params
                        pass
                    
                    # *val_resp_crc* updates
                    waitOnFlip = False
                    
                    # if val_resp_crc is starting this frame...
                    if val_resp_crc.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        val_resp_crc.frameNStart = frameN  # exact frame index
                        val_resp_crc.tStart = t  # local t and not account for scr refresh
                        val_resp_crc.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(val_resp_crc, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'val_resp_crc.started')
                        # update status
                        val_resp_crc.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(val_resp_crc.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(val_resp_crc.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    if val_resp_crc.status == STARTED and not waitOnFlip:
                        theseKeys = val_resp_crc.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                        _val_resp_crc_allKeys.extend(theseKeys)
                        if len(_val_resp_crc_allKeys):
                            val_resp_crc.keys = _val_resp_crc_allKeys[-1].name  # just the last key pressed
                            val_resp_crc.rt = _val_resp_crc_allKeys[-1].rt
                            val_resp_crc.duration = _val_resp_crc_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *image* updates
                    
                    # if image is starting this frame...
                    if image.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                        # keep track of start time/frame for later
                        image.frameNStart = frameN  # exact frame index
                        image.tStart = t  # local t and not account for scr refresh
                        image.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image.started')
                        # update status
                        image.status = STARTED
                        image.setAutoDraw(True)
                    
                    # if image is active this frame...
                    if image.status == STARTED:
                        # update params
                        pass
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in CRC_VALComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "CRC_VAL" ---
                for thisComponent in CRC_VALComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('CRC_VAL.stopped', globalClock.getTime())
                # check responses
                if val_resp_crc.keys in ['', [], None]:  # No response was made
                    val_resp_crc.keys = None
                trials_2.addData('val_resp_crc.keys',val_resp_crc.keys)
                if val_resp_crc.keys != None:  # we had a response
                    trials_2.addData('val_resp_crc.rt', val_resp_crc.rt)
                    trials_2.addData('val_resp_crc.duration', val_resp_crc.duration)
                # the Routine "CRC_VAL" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                
                # --- Prepare to start Routine "CRC_ARSL" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('CRC_ARSL.started', globalClock.getTime())
                text_arsl_2.setText('When you see this shape, \nhow TENSE / CALM do you feel? ')
                arsl_resp_crc.keys = []
                arsl_resp_crc.rt = []
                _arsl_resp_crc_allKeys = []
                # keep track of which components have finished
                CRC_ARSLComponents = [text_arsl_2, SAM_arsl_2, arsl_resp_crc, image_2]
                for thisComponent in CRC_ARSLComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "CRC_ARSL" ---
                routineForceEnded = not continueRoutine
                while continueRoutine:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *text_arsl_2* updates
                    
                    # if text_arsl_2 is starting this frame...
                    if text_arsl_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                        # keep track of start time/frame for later
                        text_arsl_2.frameNStart = frameN  # exact frame index
                        text_arsl_2.tStart = t  # local t and not account for scr refresh
                        text_arsl_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(text_arsl_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_arsl_2.started')
                        # update status
                        text_arsl_2.status = STARTED
                        text_arsl_2.setAutoDraw(True)
                    
                    # if text_arsl_2 is active this frame...
                    if text_arsl_2.status == STARTED:
                        # update params
                        pass
                    
                    # *SAM_arsl_2* updates
                    
                    # if SAM_arsl_2 is starting this frame...
                    if SAM_arsl_2.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        SAM_arsl_2.frameNStart = frameN  # exact frame index
                        SAM_arsl_2.tStart = t  # local t and not account for scr refresh
                        SAM_arsl_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(SAM_arsl_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'SAM_arsl_2.started')
                        # update status
                        SAM_arsl_2.status = STARTED
                        SAM_arsl_2.setAutoDraw(True)
                    
                    # if SAM_arsl_2 is active this frame...
                    if SAM_arsl_2.status == STARTED:
                        # update params
                        pass
                    
                    # *arsl_resp_crc* updates
                    waitOnFlip = False
                    
                    # if arsl_resp_crc is starting this frame...
                    if arsl_resp_crc.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        arsl_resp_crc.frameNStart = frameN  # exact frame index
                        arsl_resp_crc.tStart = t  # local t and not account for scr refresh
                        arsl_resp_crc.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(arsl_resp_crc, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'arsl_resp_crc.started')
                        # update status
                        arsl_resp_crc.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(arsl_resp_crc.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(arsl_resp_crc.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    if arsl_resp_crc.status == STARTED and not waitOnFlip:
                        theseKeys = arsl_resp_crc.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                        _arsl_resp_crc_allKeys.extend(theseKeys)
                        if len(_arsl_resp_crc_allKeys):
                            arsl_resp_crc.keys = _arsl_resp_crc_allKeys[-1].name  # just the last key pressed
                            arsl_resp_crc.rt = _arsl_resp_crc_allKeys[-1].rt
                            arsl_resp_crc.duration = _arsl_resp_crc_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *image_2* updates
                    
                    # if image_2 is starting this frame...
                    if image_2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                        # keep track of start time/frame for later
                        image_2.frameNStart = frameN  # exact frame index
                        image_2.tStart = t  # local t and not account for scr refresh
                        image_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_2.started')
                        # update status
                        image_2.status = STARTED
                        image_2.setAutoDraw(True)
                    
                    # if image_2 is active this frame...
                    if image_2.status == STARTED:
                        # update params
                        pass
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in CRC_ARSLComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "CRC_ARSL" ---
                for thisComponent in CRC_ARSLComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('CRC_ARSL.stopped', globalClock.getTime())
                # check responses
                if arsl_resp_crc.keys in ['', [], None]:  # No response was made
                    arsl_resp_crc.keys = None
                trials_2.addData('arsl_resp_crc.keys',arsl_resp_crc.keys)
                if arsl_resp_crc.keys != None:  # we had a response
                    trials_2.addData('arsl_resp_crc.rt', arsl_resp_crc.rt)
                    trials_2.addData('arsl_resp_crc.duration', arsl_resp_crc.duration)
                # the Routine "CRC_ARSL" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                thisExp.nextEntry()
                
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
            # completed 1.0 repeats of 'trials_2'
            
            
            # set up handler to look after randomisation of conditions etc
            trials_3 = data.TrialHandler(nReps=1.0, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=[None],
                seed=None, name='trials_3')
            thisExp.addLoop(trials_3)  # add the loop to the experiment
            thisTrial_3 = trials_3.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
            if thisTrial_3 != None:
                for paramName in thisTrial_3:
                    globals()[paramName] = thisTrial_3[paramName]
            
            for thisTrial_3 in trials_3:
                currentLoop = trials_3
                thisExp.timestampOnFlip(win, 'thisRow.t')
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        inputs=inputs, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                )
                # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
                if thisTrial_3 != None:
                    for paramName in thisTrial_3:
                        globals()[paramName] = thisTrial_3[paramName]
                
                # --- Prepare to start Routine "SQ_EXP" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('SQ_EXP.started', globalClock.getTime())
                expect_txt_3.setText('When you see this shape, \ndo you EXPECT an electric shock? ')
                slider_4.reset()
                exp_resp_sq.keys = []
                exp_resp_sq.rt = []
                _exp_resp_sq_allKeys = []
                # keep track of which components have finished
                SQ_EXPComponents = [expect_txt_3, slider_4, exp_resp_sq, expect_rating_3, image_sqr]
                for thisComponent in SQ_EXPComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "SQ_EXP" ---
                routineForceEnded = not continueRoutine
                while continueRoutine:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *expect_txt_3* updates
                    
                    # if expect_txt_3 is starting this frame...
                    if expect_txt_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                        # keep track of start time/frame for later
                        expect_txt_3.frameNStart = frameN  # exact frame index
                        expect_txt_3.tStart = t  # local t and not account for scr refresh
                        expect_txt_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(expect_txt_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'expect_txt_3.started')
                        # update status
                        expect_txt_3.status = STARTED
                        expect_txt_3.setAutoDraw(True)
                    
                    # if expect_txt_3 is active this frame...
                    if expect_txt_3.status == STARTED:
                        # update params
                        pass
                    
                    # *slider_4* updates
                    
                    # if slider_4 is starting this frame...
                    if slider_4.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        slider_4.frameNStart = frameN  # exact frame index
                        slider_4.tStart = t  # local t and not account for scr refresh
                        slider_4.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(slider_4, 'tStartRefresh')  # time at next scr refresh
                        # update status
                        slider_4.status = STARTED
                        slider_4.setAutoDraw(True)
                    
                    # if slider_4 is active this frame...
                    if slider_4.status == STARTED:
                        # update params
                        pass
                    
                    # *exp_resp_sq* updates
                    waitOnFlip = False
                    
                    # if exp_resp_sq is starting this frame...
                    if exp_resp_sq.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        exp_resp_sq.frameNStart = frameN  # exact frame index
                        exp_resp_sq.tStart = t  # local t and not account for scr refresh
                        exp_resp_sq.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(exp_resp_sq, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'exp_resp_sq.started')
                        # update status
                        exp_resp_sq.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(exp_resp_sq.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(exp_resp_sq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    if exp_resp_sq.status == STARTED and not waitOnFlip:
                        theseKeys = exp_resp_sq.getKeys(keyList=['1','2','3','4','5'], ignoreKeys=["escape"], waitRelease=False)
                        _exp_resp_sq_allKeys.extend(theseKeys)
                        if len(_exp_resp_sq_allKeys):
                            exp_resp_sq.keys = _exp_resp_sq_allKeys[-1].name  # just the last key pressed
                            exp_resp_sq.rt = _exp_resp_sq_allKeys[-1].rt
                            exp_resp_sq.duration = _exp_resp_sq_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *expect_rating_3* updates
                    
                    # if expect_rating_3 is starting this frame...
                    if expect_rating_3.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        expect_rating_3.frameNStart = frameN  # exact frame index
                        expect_rating_3.tStart = t  # local t and not account for scr refresh
                        expect_rating_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(expect_rating_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'expect_rating_3.started')
                        # update status
                        expect_rating_3.status = STARTED
                        expect_rating_3.setAutoDraw(True)
                    
                    # if expect_rating_3 is active this frame...
                    if expect_rating_3.status == STARTED:
                        # update params
                        pass
                    
                    # *image_sqr* updates
                    
                    # if image_sqr is starting this frame...
                    if image_sqr.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                        # keep track of start time/frame for later
                        image_sqr.frameNStart = frameN  # exact frame index
                        image_sqr.tStart = t  # local t and not account for scr refresh
                        image_sqr.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_sqr, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_sqr.started')
                        # update status
                        image_sqr.status = STARTED
                        image_sqr.setAutoDraw(True)
                    
                    # if image_sqr is active this frame...
                    if image_sqr.status == STARTED:
                        # update params
                        pass
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in SQ_EXPComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "SQ_EXP" ---
                for thisComponent in SQ_EXPComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('SQ_EXP.stopped', globalClock.getTime())
                trials_3.addData('slider_4.response', slider_4.getRating())
                trials_3.addData('slider_4.history', slider_4.getHistory())
                # check responses
                if exp_resp_sq.keys in ['', [], None]:  # No response was made
                    exp_resp_sq.keys = None
                trials_3.addData('exp_resp_sq.keys',exp_resp_sq.keys)
                if exp_resp_sq.keys != None:  # we had a response
                    trials_3.addData('exp_resp_sq.rt', exp_resp_sq.rt)
                    trials_3.addData('exp_resp_sq.duration', exp_resp_sq.duration)
                # the Routine "SQ_EXP" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                
                # --- Prepare to start Routine "SQ_VAL" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('SQ_VAL.started', globalClock.getTime())
                val_text_3.setText('When you see this shape, \nhow POSITIVE / NEGATIVE do you feel? ')
                val_resp_sq.keys = []
                val_resp_sq.rt = []
                _val_resp_sq_allKeys = []
                # keep track of which components have finished
                SQ_VALComponents = [val_text_3, SAM_val_3, val_resp_sq, image_sqr_2]
                for thisComponent in SQ_VALComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "SQ_VAL" ---
                routineForceEnded = not continueRoutine
                while continueRoutine:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *val_text_3* updates
                    
                    # if val_text_3 is starting this frame...
                    if val_text_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                        # keep track of start time/frame for later
                        val_text_3.frameNStart = frameN  # exact frame index
                        val_text_3.tStart = t  # local t and not account for scr refresh
                        val_text_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(val_text_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'val_text_3.started')
                        # update status
                        val_text_3.status = STARTED
                        val_text_3.setAutoDraw(True)
                    
                    # if val_text_3 is active this frame...
                    if val_text_3.status == STARTED:
                        # update params
                        pass
                    
                    # *SAM_val_3* updates
                    
                    # if SAM_val_3 is starting this frame...
                    if SAM_val_3.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        SAM_val_3.frameNStart = frameN  # exact frame index
                        SAM_val_3.tStart = t  # local t and not account for scr refresh
                        SAM_val_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(SAM_val_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'SAM_val_3.started')
                        # update status
                        SAM_val_3.status = STARTED
                        SAM_val_3.setAutoDraw(True)
                    
                    # if SAM_val_3 is active this frame...
                    if SAM_val_3.status == STARTED:
                        # update params
                        pass
                    
                    # *val_resp_sq* updates
                    waitOnFlip = False
                    
                    # if val_resp_sq is starting this frame...
                    if val_resp_sq.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        val_resp_sq.frameNStart = frameN  # exact frame index
                        val_resp_sq.tStart = t  # local t and not account for scr refresh
                        val_resp_sq.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(val_resp_sq, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'val_resp_sq.started')
                        # update status
                        val_resp_sq.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(val_resp_sq.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(val_resp_sq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    if val_resp_sq.status == STARTED and not waitOnFlip:
                        theseKeys = val_resp_sq.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                        _val_resp_sq_allKeys.extend(theseKeys)
                        if len(_val_resp_sq_allKeys):
                            val_resp_sq.keys = _val_resp_sq_allKeys[-1].name  # just the last key pressed
                            val_resp_sq.rt = _val_resp_sq_allKeys[-1].rt
                            val_resp_sq.duration = _val_resp_sq_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *image_sqr_2* updates
                    
                    # if image_sqr_2 is starting this frame...
                    if image_sqr_2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                        # keep track of start time/frame for later
                        image_sqr_2.frameNStart = frameN  # exact frame index
                        image_sqr_2.tStart = t  # local t and not account for scr refresh
                        image_sqr_2.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_sqr_2, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_sqr_2.started')
                        # update status
                        image_sqr_2.status = STARTED
                        image_sqr_2.setAutoDraw(True)
                    
                    # if image_sqr_2 is active this frame...
                    if image_sqr_2.status == STARTED:
                        # update params
                        pass
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in SQ_VALComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "SQ_VAL" ---
                for thisComponent in SQ_VALComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('SQ_VAL.stopped', globalClock.getTime())
                # check responses
                if val_resp_sq.keys in ['', [], None]:  # No response was made
                    val_resp_sq.keys = None
                trials_3.addData('val_resp_sq.keys',val_resp_sq.keys)
                if val_resp_sq.keys != None:  # we had a response
                    trials_3.addData('val_resp_sq.rt', val_resp_sq.rt)
                    trials_3.addData('val_resp_sq.duration', val_resp_sq.duration)
                # the Routine "SQ_VAL" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                
                # --- Prepare to start Routine "SQ_ARSL" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('SQ_ARSL.started', globalClock.getTime())
                text_arsl_3.setText('When you see this shape, \nhow TENSE / CALM do you feel? ')
                arsl_resp_sq.keys = []
                arsl_resp_sq.rt = []
                _arsl_resp_sq_allKeys = []
                # keep track of which components have finished
                SQ_ARSLComponents = [image_sqr_3, text_arsl_3, SAM_arsl_3, arsl_resp_sq]
                for thisComponent in SQ_ARSLComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "SQ_ARSL" ---
                routineForceEnded = not continueRoutine
                while continueRoutine:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *image_sqr_3* updates
                    
                    # if image_sqr_3 is starting this frame...
                    if image_sqr_3.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                        # keep track of start time/frame for later
                        image_sqr_3.frameNStart = frameN  # exact frame index
                        image_sqr_3.tStart = t  # local t and not account for scr refresh
                        image_sqr_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_sqr_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_sqr_3.started')
                        # update status
                        image_sqr_3.status = STARTED
                        image_sqr_3.setAutoDraw(True)
                    
                    # if image_sqr_3 is active this frame...
                    if image_sqr_3.status == STARTED:
                        # update params
                        pass
                    
                    # *text_arsl_3* updates
                    
                    # if text_arsl_3 is starting this frame...
                    if text_arsl_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                        # keep track of start time/frame for later
                        text_arsl_3.frameNStart = frameN  # exact frame index
                        text_arsl_3.tStart = t  # local t and not account for scr refresh
                        text_arsl_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(text_arsl_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_arsl_3.started')
                        # update status
                        text_arsl_3.status = STARTED
                        text_arsl_3.setAutoDraw(True)
                    
                    # if text_arsl_3 is active this frame...
                    if text_arsl_3.status == STARTED:
                        # update params
                        pass
                    
                    # *SAM_arsl_3* updates
                    
                    # if SAM_arsl_3 is starting this frame...
                    if SAM_arsl_3.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        SAM_arsl_3.frameNStart = frameN  # exact frame index
                        SAM_arsl_3.tStart = t  # local t and not account for scr refresh
                        SAM_arsl_3.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(SAM_arsl_3, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'SAM_arsl_3.started')
                        # update status
                        SAM_arsl_3.status = STARTED
                        SAM_arsl_3.setAutoDraw(True)
                    
                    # if SAM_arsl_3 is active this frame...
                    if SAM_arsl_3.status == STARTED:
                        # update params
                        pass
                    
                    # *arsl_resp_sq* updates
                    waitOnFlip = False
                    
                    # if arsl_resp_sq is starting this frame...
                    if arsl_resp_sq.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                        # keep track of start time/frame for later
                        arsl_resp_sq.frameNStart = frameN  # exact frame index
                        arsl_resp_sq.tStart = t  # local t and not account for scr refresh
                        arsl_resp_sq.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(arsl_resp_sq, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'arsl_resp_sq.started')
                        # update status
                        arsl_resp_sq.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(arsl_resp_sq.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(arsl_resp_sq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    if arsl_resp_sq.status == STARTED and not waitOnFlip:
                        theseKeys = arsl_resp_sq.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                        _arsl_resp_sq_allKeys.extend(theseKeys)
                        if len(_arsl_resp_sq_allKeys):
                            arsl_resp_sq.keys = _arsl_resp_sq_allKeys[-1].name  # just the last key pressed
                            arsl_resp_sq.rt = _arsl_resp_sq_allKeys[-1].rt
                            arsl_resp_sq.duration = _arsl_resp_sq_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in SQ_ARSLComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "SQ_ARSL" ---
                for thisComponent in SQ_ARSLComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('SQ_ARSL.stopped', globalClock.getTime())
                # check responses
                if arsl_resp_sq.keys in ['', [], None]:  # No response was made
                    arsl_resp_sq.keys = None
                trials_3.addData('arsl_resp_sq.keys',arsl_resp_sq.keys)
                if arsl_resp_sq.keys != None:  # we had a response
                    trials_3.addData('arsl_resp_sq.rt', arsl_resp_sq.rt)
                    trials_3.addData('arsl_resp_sq.duration', arsl_resp_sq.duration)
                # the Routine "SQ_ARSL" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                thisExp.nextEntry()
                
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
            # completed 1.0 repeats of 'trials_3'
            
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed 1.0 repeats of 'randomise'
        
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'RATING_PRAC'
    
    
    # --- Prepare to start Routine "INSTR" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('INSTR.started', globalClock.getTime())
    ok1.keys = []
    ok1.rt = []
    _ok1_allKeys = []
    # keep track of which components have finished
    INSTRComponents = [instruct1, ok1]
    for thisComponent in INSTRComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "INSTR" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1* updates
        
        # if instruct1 is starting this frame...
        if instruct1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1.frameNStart = frameN  # exact frame index
            instruct1.tStart = t  # local t and not account for scr refresh
            instruct1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1.started')
            # update status
            instruct1.status = STARTED
            instruct1.setAutoDraw(True)
        
        # if instruct1 is active this frame...
        if instruct1.status == STARTED:
            # update params
            pass
        
        # *ok1* updates
        waitOnFlip = False
        
        # if ok1 is starting this frame...
        if ok1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1.frameNStart = frameN  # exact frame index
            ok1.tStart = t  # local t and not account for scr refresh
            ok1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1.started')
            # update status
            ok1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1.status == STARTED and not waitOnFlip:
            theseKeys = ok1.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_allKeys.extend(theseKeys)
            if len(_ok1_allKeys):
                ok1.keys = _ok1_allKeys[-1].name  # just the last key pressed
                ok1.rt = _ok1_allKeys[-1].rt
                ok1.duration = _ok1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in INSTRComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "INSTR" ---
    for thisComponent in INSTRComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('INSTR.stopped', globalClock.getTime())
    # check responses
    if ok1.keys in ['', [], None]:  # No response was made
        ok1.keys = None
    thisExp.addData('ok1.keys',ok1.keys)
    if ok1.keys != None:  # we had a response
        thisExp.addData('ok1.rt', ok1.rt)
        thisExp.addData('ok1.duration', ok1.duration)
    thisExp.nextEntry()
    # the Routine "INSTR" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "US_INTRO" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('US_INTRO.started', globalClock.getTime())
    ok1_2.keys = []
    ok1_2.rt = []
    _ok1_2_allKeys = []
    # keep track of which components have finished
    US_INTROComponents = [instruct1_2, ok1_2]
    for thisComponent in US_INTROComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "US_INTRO" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1_2* updates
        
        # if instruct1_2 is starting this frame...
        if instruct1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1_2.frameNStart = frameN  # exact frame index
            instruct1_2.tStart = t  # local t and not account for scr refresh
            instruct1_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1_2.started')
            # update status
            instruct1_2.status = STARTED
            instruct1_2.setAutoDraw(True)
        
        # if instruct1_2 is active this frame...
        if instruct1_2.status == STARTED:
            # update params
            pass
        
        # *ok1_2* updates
        waitOnFlip = False
        
        # if ok1_2 is starting this frame...
        if ok1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1_2.frameNStart = frameN  # exact frame index
            ok1_2.tStart = t  # local t and not account for scr refresh
            ok1_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1_2.started')
            # update status
            ok1_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1_2.status == STARTED and not waitOnFlip:
            theseKeys = ok1_2.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_2_allKeys.extend(theseKeys)
            if len(_ok1_2_allKeys):
                ok1_2.keys = _ok1_2_allKeys[-1].name  # just the last key pressed
                ok1_2.rt = _ok1_2_allKeys[-1].rt
                ok1_2.duration = _ok1_2_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code_3
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in US_INTROComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "US_INTRO" ---
    for thisComponent in US_INTROComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('US_INTRO.stopped', globalClock.getTime())
    # check responses
    if ok1_2.keys in ['', [], None]:  # No response was made
        ok1_2.keys = None
    thisExp.addData('ok1_2.keys',ok1_2.keys)
    if ok1_2.keys != None:  # we had a response
        thisExp.addData('ok1_2.rt', ok1_2.rt)
        thisExp.addData('ok1_2.duration', ok1_2.duration)
    thisExp.nextEntry()
    # the Routine "US_INTRO" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    USrate = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='USrate')
    thisExp.addLoop(USrate)  # add the loop to the experiment
    thisUSrate = USrate.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisUSrate.rgb)
    if thisUSrate != None:
        for paramName in thisUSrate:
            globals()[paramName] = thisUSrate[paramName]
    
    for thisUSrate in USrate:
        currentLoop = USrate
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisUSrate.rgb)
        if thisUSrate != None:
            for paramName in thisUSrate:
                globals()[paramName] = thisUSrate[paramName]
        
        # --- Prepare to start Routine "US" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('US.started', globalClock.getTime())
        # keep track of which components have finished
        USComponents = [p_port]
        for thisComponent in USComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "US" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 3.1:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # *p_port* updates
            
            # if p_port is starting this frame...
            if p_port.status == NOT_STARTED and t >= 3-frameTolerance:
                # keep track of start time/frame for later
                p_port.frameNStart = frameN  # exact frame index
                p_port.tStart = t  # local t and not account for scr refresh
                p_port.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_port, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.addData('p_port.started', t)
                # update status
                p_port.status = STARTED
                p_port.status = STARTED
                win.callOnFlip(p_port.setData, int(1))
            
            # if p_port is stopping this frame...
            if p_port.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_port.tStartRefresh + 0.1-frameTolerance:
                    # keep track of stop time/frame for later
                    p_port.tStop = t  # not accounting for scr refresh
                    p_port.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.addData('p_port.stopped', t)
                    # update status
                    p_port.status = FINISHED
                    win.callOnFlip(p_port.setData, int(0))
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in USComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "US" ---
        for thisComponent in USComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('US.stopped', globalClock.getTime())
        if p_port.status == STARTED:
            win.callOnFlip(p_port.setData, int(0))
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-3.100000)
        
        # --- Prepare to start Routine "ITI_3s" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('ITI_3s.started', globalClock.getTime())
        # keep track of which components have finished
        ITI_3sComponents = [iti_3]
        for thisComponent in ITI_3sComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "ITI_3s" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 3.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *iti_3* updates
            
            # if iti_3 is starting this frame...
            if iti_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                iti_3.frameNStart = frameN  # exact frame index
                iti_3.tStart = t  # local t and not account for scr refresh
                iti_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(iti_3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'iti_3.started')
                # update status
                iti_3.status = STARTED
                iti_3.setAutoDraw(True)
            
            # if iti_3 is active this frame...
            if iti_3.status == STARTED:
                # update params
                pass
            
            # if iti_3 is stopping this frame...
            if iti_3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > iti_3.tStartRefresh + 3.0-frameTolerance:
                    # keep track of stop time/frame for later
                    iti_3.tStop = t  # not accounting for scr refresh
                    iti_3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'iti_3.stopped')
                    # update status
                    iti_3.status = FINISHED
                    iti_3.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ITI_3sComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "ITI_3s" ---
        for thisComponent in ITI_3sComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('ITI_3s.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-3.000000)
        
        # --- Prepare to start Routine "US_VAL" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('US_VAL.started', globalClock.getTime())
        val_text_4.setText('How POSITIVE / NEGATIVE do you feel? ')
        val_resp_US.keys = []
        val_resp_US.rt = []
        _val_resp_US_allKeys = []
        # keep track of which components have finished
        US_VALComponents = [val_text_4, SAM_val_4, val_resp_US]
        for thisComponent in US_VALComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "US_VAL" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *val_text_4* updates
            
            # if val_text_4 is starting this frame...
            if val_text_4.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                val_text_4.frameNStart = frameN  # exact frame index
                val_text_4.tStart = t  # local t and not account for scr refresh
                val_text_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(val_text_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'val_text_4.started')
                # update status
                val_text_4.status = STARTED
                val_text_4.setAutoDraw(True)
            
            # if val_text_4 is active this frame...
            if val_text_4.status == STARTED:
                # update params
                pass
            
            # *SAM_val_4* updates
            
            # if SAM_val_4 is starting this frame...
            if SAM_val_4.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                SAM_val_4.frameNStart = frameN  # exact frame index
                SAM_val_4.tStart = t  # local t and not account for scr refresh
                SAM_val_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(SAM_val_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'SAM_val_4.started')
                # update status
                SAM_val_4.status = STARTED
                SAM_val_4.setAutoDraw(True)
            
            # if SAM_val_4 is active this frame...
            if SAM_val_4.status == STARTED:
                # update params
                pass
            
            # *val_resp_US* updates
            waitOnFlip = False
            
            # if val_resp_US is starting this frame...
            if val_resp_US.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                val_resp_US.frameNStart = frameN  # exact frame index
                val_resp_US.tStart = t  # local t and not account for scr refresh
                val_resp_US.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(val_resp_US, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'val_resp_US.started')
                # update status
                val_resp_US.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(val_resp_US.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(val_resp_US.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if val_resp_US.status == STARTED and not waitOnFlip:
                theseKeys = val_resp_US.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                _val_resp_US_allKeys.extend(theseKeys)
                if len(_val_resp_US_allKeys):
                    val_resp_US.keys = _val_resp_US_allKeys[-1].name  # just the last key pressed
                    val_resp_US.rt = _val_resp_US_allKeys[-1].rt
                    val_resp_US.duration = _val_resp_US_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in US_VALComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "US_VAL" ---
        for thisComponent in US_VALComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('US_VAL.stopped', globalClock.getTime())
        # check responses
        if val_resp_US.keys in ['', [], None]:  # No response was made
            val_resp_US.keys = None
        USrate.addData('val_resp_US.keys',val_resp_US.keys)
        if val_resp_US.keys != None:  # we had a response
            USrate.addData('val_resp_US.rt', val_resp_US.rt)
            USrate.addData('val_resp_US.duration', val_resp_US.duration)
        # the Routine "US_VAL" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "US_ARSL" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('US_ARSL.started', globalClock.getTime())
        text_arsl_4.setText('How TENSE / CALM do you feel? ')
        arsl_resp_US.keys = []
        arsl_resp_US.rt = []
        _arsl_resp_US_allKeys = []
        # keep track of which components have finished
        US_ARSLComponents = [text_arsl_4, arsl_resp_US, SAM_arsl_4]
        for thisComponent in US_ARSLComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "US_ARSL" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_arsl_4* updates
            
            # if text_arsl_4 is starting this frame...
            if text_arsl_4.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                text_arsl_4.frameNStart = frameN  # exact frame index
                text_arsl_4.tStart = t  # local t and not account for scr refresh
                text_arsl_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_arsl_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_arsl_4.started')
                # update status
                text_arsl_4.status = STARTED
                text_arsl_4.setAutoDraw(True)
            
            # if text_arsl_4 is active this frame...
            if text_arsl_4.status == STARTED:
                # update params
                pass
            
            # *arsl_resp_US* updates
            waitOnFlip = False
            
            # if arsl_resp_US is starting this frame...
            if arsl_resp_US.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                arsl_resp_US.frameNStart = frameN  # exact frame index
                arsl_resp_US.tStart = t  # local t and not account for scr refresh
                arsl_resp_US.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(arsl_resp_US, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'arsl_resp_US.started')
                # update status
                arsl_resp_US.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(arsl_resp_US.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(arsl_resp_US.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if arsl_resp_US.status == STARTED and not waitOnFlip:
                theseKeys = arsl_resp_US.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                _arsl_resp_US_allKeys.extend(theseKeys)
                if len(_arsl_resp_US_allKeys):
                    arsl_resp_US.keys = _arsl_resp_US_allKeys[-1].name  # just the last key pressed
                    arsl_resp_US.rt = _arsl_resp_US_allKeys[-1].rt
                    arsl_resp_US.duration = _arsl_resp_US_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *SAM_arsl_4* updates
            
            # if SAM_arsl_4 is starting this frame...
            if SAM_arsl_4.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                # keep track of start time/frame for later
                SAM_arsl_4.frameNStart = frameN  # exact frame index
                SAM_arsl_4.tStart = t  # local t and not account for scr refresh
                SAM_arsl_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(SAM_arsl_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'SAM_arsl_4.started')
                # update status
                SAM_arsl_4.status = STARTED
                SAM_arsl_4.setAutoDraw(True)
            
            # if SAM_arsl_4 is active this frame...
            if SAM_arsl_4.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in US_ARSLComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "US_ARSL" ---
        for thisComponent in US_ARSLComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('US_ARSL.stopped', globalClock.getTime())
        # check responses
        if arsl_resp_US.keys in ['', [], None]:  # No response was made
            arsl_resp_US.keys = None
        USrate.addData('arsl_resp_US.keys',arsl_resp_US.keys)
        if arsl_resp_US.keys != None:  # we had a response
            USrate.addData('arsl_resp_US.rt', arsl_resp_US.rt)
            USrate.addData('arsl_resp_US.duration', arsl_resp_US.duration)
        # the Routine "US_ARSL" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'USrate'
    
    
    # --- Prepare to start Routine "INSTR" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('INSTR.started', globalClock.getTime())
    ok1.keys = []
    ok1.rt = []
    _ok1_allKeys = []
    # keep track of which components have finished
    INSTRComponents = [instruct1, ok1]
    for thisComponent in INSTRComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "INSTR" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1* updates
        
        # if instruct1 is starting this frame...
        if instruct1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1.frameNStart = frameN  # exact frame index
            instruct1.tStart = t  # local t and not account for scr refresh
            instruct1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1.started')
            # update status
            instruct1.status = STARTED
            instruct1.setAutoDraw(True)
        
        # if instruct1 is active this frame...
        if instruct1.status == STARTED:
            # update params
            pass
        
        # *ok1* updates
        waitOnFlip = False
        
        # if ok1 is starting this frame...
        if ok1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1.frameNStart = frameN  # exact frame index
            ok1.tStart = t  # local t and not account for scr refresh
            ok1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1.started')
            # update status
            ok1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1.status == STARTED and not waitOnFlip:
            theseKeys = ok1.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_allKeys.extend(theseKeys)
            if len(_ok1_allKeys):
                ok1.keys = _ok1_allKeys[-1].name  # just the last key pressed
                ok1.rt = _ok1_allKeys[-1].rt
                ok1.duration = _ok1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in INSTRComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "INSTR" ---
    for thisComponent in INSTRComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('INSTR.stopped', globalClock.getTime())
    # check responses
    if ok1.keys in ['', [], None]:  # No response was made
        ok1.keys = None
    thisExp.addData('ok1.keys',ok1.keys)
    if ok1.keys != None:  # we had a response
        thisExp.addData('ok1.rt', ok1.rt)
        thisExp.addData('ok1.duration', ok1.duration)
    thisExp.nextEntry()
    # the Routine "INSTR" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "DOT_INTRO" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('DOT_INTRO.started', globalClock.getTime())
    ok1_7.keys = []
    ok1_7.rt = []
    _ok1_7_allKeys = []
    # keep track of which components have finished
    DOT_INTROComponents = [instruct1_4, ok1_7]
    for thisComponent in DOT_INTROComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "DOT_INTRO" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1_4* updates
        
        # if instruct1_4 is starting this frame...
        if instruct1_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1_4.frameNStart = frameN  # exact frame index
            instruct1_4.tStart = t  # local t and not account for scr refresh
            instruct1_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1_4, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1_4.started')
            # update status
            instruct1_4.status = STARTED
            instruct1_4.setAutoDraw(True)
        
        # if instruct1_4 is active this frame...
        if instruct1_4.status == STARTED:
            # update params
            pass
        
        # *ok1_7* updates
        waitOnFlip = False
        
        # if ok1_7 is starting this frame...
        if ok1_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1_7.frameNStart = frameN  # exact frame index
            ok1_7.tStart = t  # local t and not account for scr refresh
            ok1_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1_7, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1_7.started')
            # update status
            ok1_7.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1_7.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1_7.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1_7.status == STARTED and not waitOnFlip:
            theseKeys = ok1_7.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_7_allKeys.extend(theseKeys)
            if len(_ok1_7_allKeys):
                ok1_7.keys = _ok1_7_allKeys[-1].name  # just the last key pressed
                ok1_7.rt = _ok1_7_allKeys[-1].rt
                ok1_7.duration = _ok1_7_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code_7
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DOT_INTROComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "DOT_INTRO" ---
    for thisComponent in DOT_INTROComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('DOT_INTRO.stopped', globalClock.getTime())
    # check responses
    if ok1_7.keys in ['', [], None]:  # No response was made
        ok1_7.keys = None
    thisExp.addData('ok1_7.keys',ok1_7.keys)
    if ok1_7.keys != None:  # we had a response
        thisExp.addData('ok1_7.rt', ok1_7.rt)
        thisExp.addData('ok1_7.duration', ok1_7.duration)
    thisExp.nextEntry()
    # the Routine "DOT_INTRO" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    buff_trials = data.TrialHandler(nReps=6.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='buff_trials')
    thisExp.addLoop(buff_trials)  # add the loop to the experiment
    thisBuff_trial = buff_trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisBuff_trial.rgb)
    if thisBuff_trial != None:
        for paramName in thisBuff_trial:
            globals()[paramName] = thisBuff_trial[paramName]
    
    for thisBuff_trial in buff_trials:
        currentLoop = buff_trials
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisBuff_trial.rgb)
        if thisBuff_trial != None:
            for paramName in thisBuff_trial:
                globals()[paramName] = thisBuff_trial[paramName]
        
        # --- Prepare to start Routine "DOT_BUFF" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('DOT_BUFF.started', globalClock.getTime())
        # Run 'Begin Routine' code from code_5
        # import random for generating numbers 
        import random 
        
        # generate values for coherence, speed and direction - for RDKs
        coherence_vals = round(random.uniform(0.4, .9), 1)
        speed_vals = round(random.uniform(0.01, 0.03), 2)
        direction_vals = random.choice([0, 180])
        
        # store values 
        thisExp.addData('coherence_value',coherence_vals)
        thisExp.addData('speed_value',speed_vals)
        thisExp.addData('direction_value',direction_vals)
        dots.setDir(direction_vals)
        dots.setSpeed(speed_vals)
        dots.setFieldCoherence(coherence_vals)
        dots.refreshDots()
        buff_resp.keys = []
        buff_resp.rt = []
        _buff_resp_allKeys = []
        late_buff_response.keys = []
        late_buff_response.rt = []
        _late_buff_response_allKeys = []
        # keep track of which components have finished
        DOT_BUFFComponents = [pre_cue, dots, fixation, buff_buttons, buff_resp, late_buff_response]
        for thisComponent in DOT_BUFFComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "DOT_BUFF" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 1.7:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pre_cue* updates
            
            # if pre_cue is starting this frame...
            if pre_cue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pre_cue.frameNStart = frameN  # exact frame index
                pre_cue.tStart = t  # local t and not account for scr refresh
                pre_cue.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pre_cue, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'pre_cue.started')
                # update status
                pre_cue.status = STARTED
                pre_cue.setAutoDraw(True)
            
            # if pre_cue is active this frame...
            if pre_cue.status == STARTED:
                # update params
                pass
            
            # if pre_cue is stopping this frame...
            if pre_cue.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > pre_cue.tStartRefresh + 1.7-frameTolerance:
                    # keep track of stop time/frame for later
                    pre_cue.tStop = t  # not accounting for scr refresh
                    pre_cue.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'pre_cue.stopped')
                    # update status
                    pre_cue.status = FINISHED
                    pre_cue.setAutoDraw(False)
            
            # *dots* updates
            
            # if dots is starting this frame...
            if dots.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                dots.frameNStart = frameN  # exact frame index
                dots.tStart = t  # local t and not account for scr refresh
                dots.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(dots, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'dots.started')
                # update status
                dots.status = STARTED
                dots.setAutoDraw(True)
            
            # if dots is active this frame...
            if dots.status == STARTED:
                # update params
                pass
            
            # if dots is stopping this frame...
            if dots.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > dots.tStartRefresh + 1.2-frameTolerance:
                    # keep track of stop time/frame for later
                    dots.tStop = t  # not accounting for scr refresh
                    dots.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'dots.stopped')
                    # update status
                    dots.status = FINISHED
                    dots.setAutoDraw(False)
            
            # *fixation* updates
            
            # if fixation is starting this frame...
            if fixation.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                fixation.frameNStart = frameN  # exact frame index
                fixation.tStart = t  # local t and not account for scr refresh
                fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixation.started')
                # update status
                fixation.status = STARTED
                fixation.setAutoDraw(True)
            
            # if fixation is active this frame...
            if fixation.status == STARTED:
                # update params
                pass
            
            # if fixation is stopping this frame...
            if fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation.tStartRefresh + 1.2-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation.tStop = t  # not accounting for scr refresh
                    fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixation.stopped')
                    # update status
                    fixation.status = FINISHED
                    fixation.setAutoDraw(False)
            
            # *buff_buttons* updates
            
            # if buff_buttons is starting this frame...
            if buff_buttons.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                buff_buttons.frameNStart = frameN  # exact frame index
                buff_buttons.tStart = t  # local t and not account for scr refresh
                buff_buttons.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(buff_buttons, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'buff_buttons.started')
                # update status
                buff_buttons.status = STARTED
                buff_buttons.setAutoDraw(True)
            
            # if buff_buttons is active this frame...
            if buff_buttons.status == STARTED:
                # update params
                pass
            
            # if buff_buttons is stopping this frame...
            if buff_buttons.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > buff_buttons.tStartRefresh + 1.2-frameTolerance:
                    # keep track of stop time/frame for later
                    buff_buttons.tStop = t  # not accounting for scr refresh
                    buff_buttons.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'buff_buttons.stopped')
                    # update status
                    buff_buttons.status = FINISHED
                    buff_buttons.setAutoDraw(False)
            
            # *buff_resp* updates
            waitOnFlip = False
            
            # if buff_resp is starting this frame...
            if buff_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                buff_resp.frameNStart = frameN  # exact frame index
                buff_resp.tStart = t  # local t and not account for scr refresh
                buff_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(buff_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'buff_resp.started')
                # update status
                buff_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(buff_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(buff_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if buff_resp is stopping this frame...
            if buff_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > buff_resp.tStartRefresh + 1.2-frameTolerance:
                    # keep track of stop time/frame for later
                    buff_resp.tStop = t  # not accounting for scr refresh
                    buff_resp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'buff_resp.stopped')
                    # update status
                    buff_resp.status = FINISHED
                    buff_resp.status = FINISHED
            if buff_resp.status == STARTED and not waitOnFlip:
                theseKeys = buff_resp.getKeys(keyList=['1', '2'], ignoreKeys=["escape"], waitRelease=False)
                _buff_resp_allKeys.extend(theseKeys)
                if len(_buff_resp_allKeys):
                    buff_resp.keys = _buff_resp_allKeys[-1].name  # just the last key pressed
                    buff_resp.rt = _buff_resp_allKeys[-1].rt
                    buff_resp.duration = _buff_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *late_buff_response* updates
            waitOnFlip = False
            
            # if late_buff_response is starting this frame...
            if late_buff_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                late_buff_response.frameNStart = frameN  # exact frame index
                late_buff_response.tStart = t  # local t and not account for scr refresh
                late_buff_response.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(late_buff_response, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'late_buff_response.started')
                # update status
                late_buff_response.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(late_buff_response.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(late_buff_response.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if late_buff_response is stopping this frame...
            if late_buff_response.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > late_buff_response.tStartRefresh + .5-frameTolerance:
                    # keep track of stop time/frame for later
                    late_buff_response.tStop = t  # not accounting for scr refresh
                    late_buff_response.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'late_buff_response.stopped')
                    # update status
                    late_buff_response.status = FINISHED
                    late_buff_response.status = FINISHED
            if late_buff_response.status == STARTED and not waitOnFlip:
                theseKeys = late_buff_response.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                _late_buff_response_allKeys.extend(theseKeys)
                if len(_late_buff_response_allKeys):
                    late_buff_response.keys = _late_buff_response_allKeys[-1].name  # just the last key pressed
                    late_buff_response.rt = _late_buff_response_allKeys[-1].rt
                    late_buff_response.duration = _late_buff_response_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in DOT_BUFFComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "DOT_BUFF" ---
        for thisComponent in DOT_BUFFComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('DOT_BUFF.stopped', globalClock.getTime())
        # Run 'End Routine' code from code_5
        trial_accuracy = 0  # Default accuracy is 0
        
        if buff_resp.keys == '1':
            if direction_vals == 180:
                trial_accuracy = 1
        elif buff_resp.keys == '2':
            if direction_vals == 0:
                trial_accuracy = 1
        
        thisExp.addData('buffer_acc', trial_accuracy)
        # check responses
        if buff_resp.keys in ['', [], None]:  # No response was made
            buff_resp.keys = None
        buff_trials.addData('buff_resp.keys',buff_resp.keys)
        if buff_resp.keys != None:  # we had a response
            buff_trials.addData('buff_resp.rt', buff_resp.rt)
            buff_trials.addData('buff_resp.duration', buff_resp.duration)
        # check responses
        if late_buff_response.keys in ['', [], None]:  # No response was made
            late_buff_response.keys = None
        buff_trials.addData('late_buff_response.keys',late_buff_response.keys)
        if late_buff_response.keys != None:  # we had a response
            buff_trials.addData('late_buff_response.rt', late_buff_response.rt)
            buff_trials.addData('late_buff_response.duration', late_buff_response.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.700000)
        
        # --- Prepare to start Routine "ITI_1s" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('ITI_1s.started', globalClock.getTime())
        # keep track of which components have finished
        ITI_1sComponents = [iti_1s]
        for thisComponent in ITI_1sComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "ITI_1s" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 1.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *iti_1s* updates
            
            # if iti_1s is starting this frame...
            if iti_1s.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                iti_1s.frameNStart = frameN  # exact frame index
                iti_1s.tStart = t  # local t and not account for scr refresh
                iti_1s.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(iti_1s, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'iti_1s.started')
                # update status
                iti_1s.status = STARTED
                iti_1s.setAutoDraw(True)
            
            # if iti_1s is active this frame...
            if iti_1s.status == STARTED:
                # update params
                pass
            
            # if iti_1s is stopping this frame...
            if iti_1s.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > iti_1s.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    iti_1s.tStop = t  # not accounting for scr refresh
                    iti_1s.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'iti_1s.stopped')
                    # update status
                    iti_1s.status = FINISHED
                    iti_1s.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ITI_1sComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "ITI_1s" ---
        for thisComponent in ITI_1sComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('ITI_1s.stopped', globalClock.getTime())
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.000000)
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 6.0 repeats of 'buff_trials'
    
    
    # --- Prepare to start Routine "INSTR" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('INSTR.started', globalClock.getTime())
    ok1.keys = []
    ok1.rt = []
    _ok1_allKeys = []
    # keep track of which components have finished
    INSTRComponents = [instruct1, ok1]
    for thisComponent in INSTRComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "INSTR" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct1* updates
        
        # if instruct1 is starting this frame...
        if instruct1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1.frameNStart = frameN  # exact frame index
            instruct1.tStart = t  # local t and not account for scr refresh
            instruct1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1.started')
            # update status
            instruct1.status = STARTED
            instruct1.setAutoDraw(True)
        
        # if instruct1 is active this frame...
        if instruct1.status == STARTED:
            # update params
            pass
        
        # *ok1* updates
        waitOnFlip = False
        
        # if ok1 is starting this frame...
        if ok1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1.frameNStart = frameN  # exact frame index
            ok1.tStart = t  # local t and not account for scr refresh
            ok1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1.started')
            # update status
            ok1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1.status == STARTED and not waitOnFlip:
            theseKeys = ok1.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_allKeys.extend(theseKeys)
            if len(_ok1_allKeys):
                ok1.keys = _ok1_allKeys[-1].name  # just the last key pressed
                ok1.rt = _ok1_allKeys[-1].rt
                ok1.duration = _ok1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in INSTRComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "INSTR" ---
    for thisComponent in INSTRComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('INSTR.stopped', globalClock.getTime())
    # check responses
    if ok1.keys in ['', [], None]:  # No response was made
        ok1.keys = None
    thisExp.addData('ok1.keys',ok1.keys)
    if ok1.keys != None:  # we had a response
        thisExp.addData('ok1.rt', ok1.rt)
        thisExp.addData('ok1.duration', ok1.duration)
    thisExp.nextEntry()
    # the Routine "INSTR" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "BYST_INTRO" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('BYST_INTRO.started', globalClock.getTime())
    ok1_11.keys = []
    ok1_11.rt = []
    _ok1_11_allKeys = []
    # keep track of which components have finished
    BYST_INTROComponents = [text, ok1_11]
    for thisComponent in BYST_INTROComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "BYST_INTRO" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        
        # if text is starting this frame...
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text.started')
            # update status
            text.status = STARTED
            text.setAutoDraw(True)
        
        # if text is active this frame...
        if text.status == STARTED:
            # update params
            pass
        
        # *ok1_11* updates
        waitOnFlip = False
        
        # if ok1_11 is starting this frame...
        if ok1_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1_11.frameNStart = frameN  # exact frame index
            ok1_11.tStart = t  # local t and not account for scr refresh
            ok1_11.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1_11, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1_11.started')
            # update status
            ok1_11.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1_11.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1_11.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1_11.status == STARTED and not waitOnFlip:
            theseKeys = ok1_11.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_11_allKeys.extend(theseKeys)
            if len(_ok1_11_allKeys):
                ok1_11.keys = _ok1_11_allKeys[-1].name  # just the last key pressed
                ok1_11.rt = _ok1_11_allKeys[-1].rt
                ok1_11.duration = _ok1_11_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code_13
        your_mouse = event.Mouse(visible = False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in BYST_INTROComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "BYST_INTRO" ---
    for thisComponent in BYST_INTROComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('BYST_INTRO.stopped', globalClock.getTime())
    # check responses
    if ok1_11.keys in ['', [], None]:  # No response was made
        ok1_11.keys = None
    thisExp.addData('ok1_11.keys',ok1_11.keys)
    if ok1_11.keys != None:  # we had a response
        thisExp.addData('ok1_11.rt', ok1_11.rt)
        thisExp.addData('ok1_11.duration', ok1_11.duration)
    thisExp.nextEntry()
    # the Routine "BYST_INTRO" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    byst_trials = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('PreAcq_bystander.xlsx'),
        seed=None, name='byst_trials')
    thisExp.addLoop(byst_trials)  # add the loop to the experiment
    thisByst_trial = byst_trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisByst_trial.rgb)
    if thisByst_trial != None:
        for paramName in thisByst_trial:
            globals()[paramName] = thisByst_trial[paramName]
    
    for thisByst_trial in byst_trials:
        currentLoop = byst_trials
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisByst_trial.rgb)
        if thisByst_trial != None:
            for paramName in thisByst_trial:
                globals()[paramName] = thisByst_trial[paramName]
        
        # --- Prepare to start Routine "BYST_PRAC" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('BYST_PRAC.started', globalClock.getTime())
        txt.setText(pre_text3
        )
        image_3.setPos([0, 0])
        image_3.setImage(pre_image3)
        byst_resp.keys = []
        byst_resp.rt = []
        _byst_resp_allKeys = []
        buttons_.setText(pre_buttons3)
        # keep track of which components have finished
        BYST_PRACComponents = [txt, image_3, byst_resp, buttons_]
        for thisComponent in BYST_PRACComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "BYST_PRAC" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 5.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *txt* updates
            
            # if txt is starting this frame...
            if txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                txt.frameNStart = frameN  # exact frame index
                txt.tStart = t  # local t and not account for scr refresh
                txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'txt.started')
                # update status
                txt.status = STARTED
                txt.setAutoDraw(True)
            
            # if txt is active this frame...
            if txt.status == STARTED:
                # update params
                pass
            
            # if txt is stopping this frame...
            if txt.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > txt.tStartRefresh + 5.5-frameTolerance:
                    # keep track of stop time/frame for later
                    txt.tStop = t  # not accounting for scr refresh
                    txt.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'txt.stopped')
                    # update status
                    txt.status = FINISHED
                    txt.setAutoDraw(False)
            
            # *image_3* updates
            
            # if image_3 is starting this frame...
            if image_3.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_3.frameNStart = frameN  # exact frame index
                image_3.tStart = t  # local t and not account for scr refresh
                image_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_3.started')
                # update status
                image_3.status = STARTED
                image_3.setAutoDraw(True)
            
            # if image_3 is active this frame...
            if image_3.status == STARTED:
                # update params
                pass
            
            # if image_3 is stopping this frame...
            if image_3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_3.tStartRefresh + 5-frameTolerance:
                    # keep track of stop time/frame for later
                    image_3.tStop = t  # not accounting for scr refresh
                    image_3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_3.stopped')
                    # update status
                    image_3.status = FINISHED
                    image_3.setAutoDraw(False)
            
            # *byst_resp* updates
            waitOnFlip = False
            
            # if byst_resp is starting this frame...
            if byst_resp.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                # keep track of start time/frame for later
                byst_resp.frameNStart = frameN  # exact frame index
                byst_resp.tStart = t  # local t and not account for scr refresh
                byst_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(byst_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'byst_resp.started')
                # update status
                byst_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(byst_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(byst_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if byst_resp is stopping this frame...
            if byst_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > byst_resp.tStartRefresh + 5-frameTolerance:
                    # keep track of stop time/frame for later
                    byst_resp.tStop = t  # not accounting for scr refresh
                    byst_resp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_resp.stopped')
                    # update status
                    byst_resp.status = FINISHED
                    byst_resp.status = FINISHED
            if byst_resp.status == STARTED and not waitOnFlip:
                theseKeys = byst_resp.getKeys(keyList=["1", "2"], ignoreKeys=["escape"], waitRelease=False)
                _byst_resp_allKeys.extend(theseKeys)
                if len(_byst_resp_allKeys):
                    byst_resp.keys = _byst_resp_allKeys[-1].name  # just the last key pressed
                    byst_resp.rt = _byst_resp_allKeys[-1].rt
                    byst_resp.duration = _byst_resp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *buttons_* updates
            
            # if buttons_ is starting this frame...
            if buttons_.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                buttons_.frameNStart = frameN  # exact frame index
                buttons_.tStart = t  # local t and not account for scr refresh
                buttons_.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(buttons_, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'buttons_.started')
                # update status
                buttons_.status = STARTED
                buttons_.setAutoDraw(True)
            
            # if buttons_ is active this frame...
            if buttons_.status == STARTED:
                # update params
                pass
            
            # if buttons_ is stopping this frame...
            if buttons_.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > buttons_.tStartRefresh + 5.0-frameTolerance:
                    # keep track of stop time/frame for later
                    buttons_.tStop = t  # not accounting for scr refresh
                    buttons_.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'buttons_.stopped')
                    # update status
                    buttons_.status = FINISHED
                    buttons_.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in BYST_PRACComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "BYST_PRAC" ---
        for thisComponent in BYST_PRACComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('BYST_PRAC.stopped', globalClock.getTime())
        # check responses
        if byst_resp.keys in ['', [], None]:  # No response was made
            byst_resp.keys = None
        byst_trials.addData('byst_resp.keys',byst_resp.keys)
        if byst_resp.keys != None:  # we had a response
            byst_trials.addData('byst_resp.rt', byst_resp.rt)
            byst_trials.addData('byst_resp.duration', byst_resp.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-5.500000)
        
        # --- Prepare to start Routine "ITI_1S" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('ITI_1S.started', globalClock.getTime())
        # keep track of which components have finished
        ITI_1SComponents = []
        for thisComponent in ITI_1SComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "ITI_1S" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, inputs=inputs, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ITI_1SComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "ITI_1S" ---
        for thisComponent in ITI_1SComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('ITI_1S.stopped', globalClock.getTime())
        # the Routine "ITI_1S" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'byst_trials'
    
    
    # --- Prepare to start Routine "DONE" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('DONE.started', globalClock.getTime())
    # keep track of which components have finished
    DONEComponents = [PRACTICE_PHASE_COMPLETE__]
    for thisComponent in DONEComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "DONE" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *PRACTICE_PHASE_COMPLETE__* updates
        
        # if PRACTICE_PHASE_COMPLETE__ is starting this frame...
        if PRACTICE_PHASE_COMPLETE__.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            PRACTICE_PHASE_COMPLETE__.frameNStart = frameN  # exact frame index
            PRACTICE_PHASE_COMPLETE__.tStart = t  # local t and not account for scr refresh
            PRACTICE_PHASE_COMPLETE__.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PRACTICE_PHASE_COMPLETE__, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'PRACTICE_PHASE_COMPLETE__.started')
            # update status
            PRACTICE_PHASE_COMPLETE__.status = STARTED
            PRACTICE_PHASE_COMPLETE__.setAutoDraw(True)
        
        # if PRACTICE_PHASE_COMPLETE__ is active this frame...
        if PRACTICE_PHASE_COMPLETE__.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DONEComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "DONE" ---
    for thisComponent in DONEComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('DONE.stopped', globalClock.getTime())
    # the Routine "DONE" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    # Run 'End Experiment' code from code
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code_4
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code_6
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code_8
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code_3
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code_7
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code_13
    your_mouse = event.Mouse(visible = True)
    
    # mark experiment as finished
    endExperiment(thisExp, win=win, inputs=inputs)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, inputs=None, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    inputs : dict
        Dictionary of input devices by name.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if inputs is not None:
        if 'eyetracker' in inputs and inputs['eyetracker'] is not None:
            inputs['eyetracker'].setConnectionState(False)
    logging.flush()


def quit(thisExp, win=None, inputs=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    inputs : dict
        Dictionary of input devices by name.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    if inputs is not None:
        if 'eyetracker' in inputs and inputs['eyetracker'] is not None:
            inputs['eyetracker'].setConnectionState(False)
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    inputs = setupInputs(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win, 
        inputs=inputs
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win, inputs=inputs)
