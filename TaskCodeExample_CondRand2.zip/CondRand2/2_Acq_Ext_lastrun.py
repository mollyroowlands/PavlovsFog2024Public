﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2023.2.3),
    on December 13, 2023, at 18:18
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, parallel
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# Store info about the experiment session
psychopyVersion = '2023.2.3'
expName = '1_Acq_Ext'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
    'date': data.getDateStr(),  # add a simple timestamp
    'expName': expName,
    'psychopyVersion': psychopyVersion,
}


def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # temporarily remove keys which the dialog doesn't need to show
    poppedKeys = {
        'date': expInfo.pop('date', data.getDateStr()),
        'expName': expInfo.pop('expName', expName),
        'psychopyVersion': expInfo.pop('psychopyVersion', psychopyVersion),
    }
    # show participant info dialog
    dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # restore hidden keys
    expInfo.update(poppedKeys)
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\test143user\\Desktop\\Shapes_and_Shocks\\R2\\CB1_Shapes_and_Shocks\\2_Acq_Ext_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(logging.EXP)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=logging.EXP)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=[1920, 1080], fullscr=True, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height'
        )
        if expInfo is not None:
            # store frame rate of monitor if we can measure it
            expInfo['frameRate'] = win.getActualFrameRate()
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [-1.0000, -1.0000, -1.0000]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    win.mouseVisible = False
    win.hideMessage()
    return win


def setupInputs(expInfo, thisExp, win):
    """
    Setup whatever inputs are available (mouse, keyboard, eyetracker, etc.)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    dict
        Dictionary of input devices by name.
    """
    # --- Setup input devices ---
    inputs = {}
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    eyetracker = None
    
    # create a default keyboard (e.g. to check for escape)
    defaultKeyboard = keyboard.Keyboard(backend='iohub')
    # return inputs dict
    return {
        'ioServer': ioServer,
        'defaultKeyboard': defaultKeyboard,
        'eyetracker': eyetracker,
    }

def pauseExperiment(thisExp, inputs=None, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    inputs : dict
        Dictionary of input devices by name.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # make sure we have a keyboard
        if inputs is None:
            inputs = {
                'defaultKeyboard': keyboard.Keyboard(backend='ioHub')
            }
        # check for quit (typically the Esc key)
        if inputs['defaultKeyboard'].getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win, inputs=inputs)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, inputs=inputs, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, inputs, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    inputs : dict
        Dictionary of input devices by name.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = inputs['ioServer']
    defaultKeyboard = inputs['defaultKeyboard']
    eyetracker = inputs['eyetracker']
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "INSTR" ---
    ok1 = keyboard.Keyboard()
    instruct1 = visual.TextStim(win=win, name='instruct1',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "CS" ---
    CS_stim = visual.ImageStim(
        win=win,
        name='CS_stim', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=0.0)
    
    # --- Initialize components for Routine "ITI" ---
    iti = visual.TextStim(win=win, name='iti',
        text=None,
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "CS_US" ---
    CS_stim_2 = visual.ImageStim(
        win=win,
        name='CS_stim_2', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=0.0)
    p_port = parallel.ParallelPort(address='0xDFF8')
    
    # --- Initialize components for Routine "ITI" ---
    iti = visual.TextStim(win=win, name='iti',
        text=None,
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "buffer_new" ---
    pre_cue = visual.TextStim(win=win, name='pre_cue',
        text='direction?',
        font='Open Sans',
        pos=(0, .4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    dots = visual.DotStim(
        win=win, name='dots',
        nDots=100, dotSize=8.0,
        speed=1.0, dir=1.0, coherence=1.0,
        fieldPos=(0.0, 0.0), fieldSize=0.5, fieldAnchor='center', fieldShape='circle',
        signalDots='same', noiseDots='direction',dotLife=1000.0,
        color=[0.9216, 0.9216, 0.9216], colorSpace='rgb', opacity=None,
        depth=-2.0)
    fixation = visual.TextStim(win=win, name='fixation',
        text='+',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    buff_buttons = visual.TextStim(win=win, name='buff_buttons',
        text=' (1)                (2)\n<--               -->',
        font='Open Sans',
        pos=(0, -.3), height=0.04, wrapWidth=None, ori=0.0, 
        color='DarkGrey', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    buff_resp = keyboard.Keyboard()
    late_buff_response = keyboard.Keyboard()
    
    # --- Initialize components for Routine "bystander" ---
    bystander_precue_3 = visual.TextStim(win=win, name='bystander_precue_3',
        text='seen before?',
        font='Open Sans',
        pos=(0, 0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='DarkSeaGreen', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    bystander_image_ext = visual.ImageStim(
        win=win,
        name='bystander_image_ext', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(420,340),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    byst_resp_acq = keyboard.Keyboard()
    byst_buttons_ext = visual.TextStim(win=win, name='byst_buttons_ext',
        text=' (1)                (2)\nyes               no',
        font='Open Sans',
        pos=(0, -0.3), height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    byst_earlyresp_acq = keyboard.Keyboard()
    
    # --- Initialize components for Routine "EXP_acq" ---
    expect_txt = visual.TextStim(win=win, name='expect_txt',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    slider_3 = visual.Slider(win=win, name='slider_3',
        startValue=None, size=(1.0, 0.04), pos=(0, -0.3), units=win.units,
        labels=["yes, definitely expect a shock (100%)","unsure (50%)","no, definitely don't expect a shock (0%)"], ticks=(1, 2, 3, 4, 5), granularity=0.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor=[1.0000, 1.0000, 1.0000], markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.025,
        flip=False, ori=0.0, depth=-1, readOnly=False)
    exp_resp_acq = keyboard.Keyboard()
    expect_rating = visual.ImageStim(
        win=win,
        name='expect_rating', 
        image='stims/ExpectRating/expect.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.2), size=(1.15, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    CS_stim_4 = visual.ImageStim(
        win=win,
        name='CS_stim_4', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-4.0)
    
    # --- Initialize components for Routine "VAL_acq" ---
    val_text = visual.TextStim(win=win, name='val_text',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_val = visual.ImageStim(
        win=win,
        name='SAM_val', 
        image='stims/SAM/valence.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    resp_val_acq = keyboard.Keyboard()
    CS_stim_6 = visual.ImageStim(
        win=win,
        name='CS_stim_6', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "ARSL_acq" ---
    text_arsl = visual.TextStim(win=win, name='text_arsl',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_arsl = visual.ImageStim(
        win=win,
        name='SAM_arsl', 
        image='stims/SAM/arousal.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    resp_arsl_acq = keyboard.Keyboard()
    CS_stim_7 = visual.ImageStim(
        win=win,
        name='CS_stim_7', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "CS_ext" ---
    CS_stim_3 = visual.ImageStim(
        win=win,
        name='CS_stim_3', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=0.0)
    
    # --- Initialize components for Routine "ITI" ---
    iti = visual.TextStim(win=win, name='iti',
        text=None,
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "buffer_new" ---
    pre_cue = visual.TextStim(win=win, name='pre_cue',
        text='direction?',
        font='Open Sans',
        pos=(0, .4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    dots = visual.DotStim(
        win=win, name='dots',
        nDots=100, dotSize=8.0,
        speed=1.0, dir=1.0, coherence=1.0,
        fieldPos=(0.0, 0.0), fieldSize=0.5, fieldAnchor='center', fieldShape='circle',
        signalDots='same', noiseDots='direction',dotLife=1000.0,
        color=[0.9216, 0.9216, 0.9216], colorSpace='rgb', opacity=None,
        depth=-2.0)
    fixation = visual.TextStim(win=win, name='fixation',
        text='+',
        font='Open Sans',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    buff_buttons = visual.TextStim(win=win, name='buff_buttons',
        text=' (1)                (2)\n<--               -->',
        font='Open Sans',
        pos=(0, -.3), height=0.04, wrapWidth=None, ori=0.0, 
        color='DarkGrey', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    buff_resp = keyboard.Keyboard()
    late_buff_response = keyboard.Keyboard()
    
    # --- Initialize components for Routine "bystander_ext" ---
    bystander_precue = visual.TextStim(win=win, name='bystander_precue',
        text='seen before?',
        font='Open Sans',
        pos=(0, .4), height=0.05, wrapWidth=None, ori=0.0, 
        color='DarkSeaGreen', colorSpace='rgb', opacity=1.0, 
        languageStyle='LTR',
        depth=0.0);
    bystander_image_ext_2 = visual.ImageStim(
        win=win,
        name='bystander_image_ext_2', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(420,340),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    byst_resp_ext = keyboard.Keyboard()
    byst_buttons_ext_2 = visual.TextStim(win=win, name='byst_buttons_ext_2',
        text=' (1)                (2)\nyes               no',
        font='Open Sans',
        pos=(0, -0.3), height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    byst_earlyresp_ext = keyboard.Keyboard()
    
    # --- Initialize components for Routine "ARSL_ext" ---
    text_arsl_2 = visual.TextStim(win=win, name='text_arsl_2',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_arsl_2 = visual.ImageStim(
        win=win,
        name='SAM_arsl_2', 
        image='stims/SAM/arousal.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    resp_arsl_ext = keyboard.Keyboard()
    CS_stim_5 = visual.ImageStim(
        win=win,
        name='CS_stim_5', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "EXP_ext" ---
    expect_txt_2 = visual.TextStim(win=win, name='expect_txt_2',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    slider = visual.Slider(win=win, name='slider',
        startValue=None, size=(1.0, 0.04), pos=(0, -0.3), units=win.units,
        labels=["yes, definitely expect a shock (100%)","unsure (50%)","no, definitely don't expect a shock (0%)"], ticks=(1, 2, 3, 4, 5), granularity=0.0,
        style='rating', styleTweaks=(), opacity=None,
        labelColor=[1.0000, 1.0000, 1.0000], markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Open Sans', labelHeight=0.025,
        flip=False, ori=0.0, depth=-1, readOnly=False)
    exp_resp_ext = keyboard.Keyboard()
    expect_rating_2 = visual.ImageStim(
        win=win,
        name='expect_rating_2', 
        image='stims/ExpectRating/expect.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.2), size=(1.15, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    CS_stim_8 = visual.ImageStim(
        win=win,
        name='CS_stim_8', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-4.0)
    
    # --- Initialize components for Routine "VAL_ext" ---
    val_text_2 = visual.TextStim(win=win, name='val_text_2',
        text='',
        font='Open Sans',
        pos=(0, 0.35), height=.04, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    SAM_val_2 = visual.ImageStim(
        win=win,
        name='SAM_val_2', 
        image='stims/SAM/valence.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.3), size=(1.1, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    resp__val_ext = keyboard.Keyboard()
    CS_stim_9 = visual.ImageStim(
        win=win,
        name='CS_stim_9', units='pix', 
        image='default.png', mask=None, anchor='center',
        ori=0, pos=[0,0], size=[320,240],
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=512, interpolate=True, depth=-3.0)
    
    # --- Initialize components for Routine "CONT_CHECK" ---
    text = visual.TextStim(win=win, name='text',
        text='Which shape was linked to the shocks? \n\n\nPress the "C" key for the BLUE CIRCLE\n\nPress the "S" key for the YELLOW SQUARE\n \nPress the "N" key if you DO NOT KNOW / ARE UNSURE ',
        font='Open Sans',
        pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    cont_resp = keyboard.Keyboard()
    
    # --- Initialize components for Routine "INSTR" ---
    ok1 = keyboard.Keyboard()
    instruct1 = visual.TextStim(win=win, name='instruct1',
        text='WAIT FOR INSTRUCTIONS\n\nTHEN PRESS ANY KEY TO BEGIN',
        font='Open Sans',
        pos=[0, 0], height=0.04, wrapWidth=None, ori=0, 
        color='LightBlue', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-2.0);
    
    # create some handy timers
    if globalClock is None:
        globalClock = core.Clock()  # to track the time since experiment started
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6)
    
    # --- Prepare to start Routine "INSTR" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('INSTR.started', globalClock.getTime())
    ok1.keys = []
    ok1.rt = []
    _ok1_allKeys = []
    # keep track of which components have finished
    INSTRComponents = [ok1, instruct1]
    for thisComponent in INSTRComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "INSTR" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ok1* updates
        waitOnFlip = False
        
        # if ok1 is starting this frame...
        if ok1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1.frameNStart = frameN  # exact frame index
            ok1.tStart = t  # local t and not account for scr refresh
            ok1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1.started')
            # update status
            ok1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1.status == STARTED and not waitOnFlip:
            theseKeys = ok1.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_allKeys.extend(theseKeys)
            if len(_ok1_allKeys):
                ok1.keys = _ok1_allKeys[-1].name  # just the last key pressed
                ok1.rt = _ok1_allKeys[-1].rt
                ok1.duration = _ok1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code
        your_mouse = event.Mouse(visible = False)
        
        # *instruct1* updates
        
        # if instruct1 is starting this frame...
        if instruct1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1.frameNStart = frameN  # exact frame index
            instruct1.tStart = t  # local t and not account for scr refresh
            instruct1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1.started')
            # update status
            instruct1.status = STARTED
            instruct1.setAutoDraw(True)
        
        # if instruct1 is active this frame...
        if instruct1.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in INSTRComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "INSTR" ---
    for thisComponent in INSTRComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('INSTR.stopped', globalClock.getTime())
    # check responses
    if ok1.keys in ['', [], None]:  # No response was made
        ok1.keys = None
    thisExp.addData('ok1.keys',ok1.keys)
    if ok1.keys != None:  # we had a response
        thisExp.addData('ok1.rt', ok1.rt)
        thisExp.addData('ok1.duration', ok1.duration)
    thisExp.nextEntry()
    # the Routine "INSTR" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Acquisition = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Acquisiton.xlsx'),
        seed=None, name='Acquisition')
    thisExp.addLoop(Acquisition)  # add the loop to the experiment
    thisAcquisition = Acquisition.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisAcquisition.rgb)
    if thisAcquisition != None:
        for paramName in thisAcquisition:
            globals()[paramName] = thisAcquisition[paramName]
    
    for thisAcquisition in Acquisition:
        currentLoop = Acquisition
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisAcquisition.rgb)
        if thisAcquisition != None:
            for paramName in thisAcquisition:
                globals()[paramName] = thisAcquisition[paramName]
        
        # set up handler to look after randomisation of conditions etc
        CS_trials = data.TrialHandler(nReps=int(trial_type_acq=='noUS'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='CS_trials')
        thisExp.addLoop(CS_trials)  # add the loop to the experiment
        thisCS_trial = CS_trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisCS_trial.rgb)
        if thisCS_trial != None:
            for paramName in thisCS_trial:
                globals()[paramName] = thisCS_trial[paramName]
        
        for thisCS_trial in CS_trials:
            currentLoop = CS_trials
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisCS_trial.rgb)
            if thisCS_trial != None:
                for paramName in thisCS_trial:
                    globals()[paramName] = thisCS_trial[paramName]
            
            # --- Prepare to start Routine "CS" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('CS.started', globalClock.getTime())
            CS_stim.setPos([0, 0])
            CS_stim.setImage(image_acq)
            # keep track of which components have finished
            CSComponents = [CS_stim]
            for thisComponent in CSComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "CS" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 3.25:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *CS_stim* updates
                
                # if CS_stim is starting this frame...
                if CS_stim.status == NOT_STARTED and tThisFlip >= .750-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim.frameNStart = frameN  # exact frame index
                    CS_stim.tStart = t  # local t and not account for scr refresh
                    CS_stim.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim.started')
                    # update status
                    CS_stim.status = STARTED
                    CS_stim.setAutoDraw(True)
                
                # if CS_stim is active this frame...
                if CS_stim.status == STARTED:
                    # update params
                    pass
                
                # if CS_stim is stopping this frame...
                if CS_stim.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > CS_stim.tStartRefresh + 2.5-frameTolerance:
                        # keep track of stop time/frame for later
                        CS_stim.tStop = t  # not accounting for scr refresh
                        CS_stim.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'CS_stim.stopped')
                        # update status
                        CS_stim.status = FINISHED
                        CS_stim.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in CSComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "CS" ---
            for thisComponent in CSComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('CS.stopped', globalClock.getTime())
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-3.250000)
            
            # --- Prepare to start Routine "ITI" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('ITI.started', globalClock.getTime())
            # keep track of which components have finished
            ITIComponents = [iti]
            for thisComponent in ITIComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "ITI" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *iti* updates
                
                # if iti is starting this frame...
                if iti.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    iti.frameNStart = frameN  # exact frame index
                    iti.tStart = t  # local t and not account for scr refresh
                    iti.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(iti, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'iti.started')
                    # update status
                    iti.status = STARTED
                    iti.setAutoDraw(True)
                
                # if iti is active this frame...
                if iti.status == STARTED:
                    # update params
                    pass
                
                # if iti is stopping this frame...
                if iti.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > iti.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        iti.tStop = t  # not accounting for scr refresh
                        iti.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'iti.stopped')
                        # update status
                        iti.status = FINISHED
                        iti.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in ITIComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "ITI" ---
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('ITI.stopped', globalClock.getTime())
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='noUS') repeats of 'CS_trials'
        
        
        # set up handler to look after randomisation of conditions etc
        US_trigger = data.TrialHandler(nReps=int(trial_type_acq=='US'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='US_trigger')
        thisExp.addLoop(US_trigger)  # add the loop to the experiment
        thisUS_trigger = US_trigger.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisUS_trigger.rgb)
        if thisUS_trigger != None:
            for paramName in thisUS_trigger:
                globals()[paramName] = thisUS_trigger[paramName]
        
        for thisUS_trigger in US_trigger:
            currentLoop = US_trigger
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisUS_trigger.rgb)
            if thisUS_trigger != None:
                for paramName in thisUS_trigger:
                    globals()[paramName] = thisUS_trigger[paramName]
            
            # --- Prepare to start Routine "CS_US" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('CS_US.started', globalClock.getTime())
            CS_stim_2.setPos([0, 0])
            CS_stim_2.setImage(image_acq)
            # keep track of which components have finished
            CS_USComponents = [CS_stim_2, p_port]
            for thisComponent in CS_USComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "CS_US" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 3.25:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *CS_stim_2* updates
                
                # if CS_stim_2 is starting this frame...
                if CS_stim_2.status == NOT_STARTED and tThisFlip >= .750-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_2.frameNStart = frameN  # exact frame index
                    CS_stim_2.tStart = t  # local t and not account for scr refresh
                    CS_stim_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_2.started')
                    # update status
                    CS_stim_2.status = STARTED
                    CS_stim_2.setAutoDraw(True)
                
                # if CS_stim_2 is active this frame...
                if CS_stim_2.status == STARTED:
                    # update params
                    pass
                
                # if CS_stim_2 is stopping this frame...
                if CS_stim_2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > CS_stim_2.tStartRefresh + 2.5-frameTolerance:
                        # keep track of stop time/frame for later
                        CS_stim_2.tStop = t  # not accounting for scr refresh
                        CS_stim_2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'CS_stim_2.stopped')
                        # update status
                        CS_stim_2.status = FINISHED
                        CS_stim_2.setAutoDraw(False)
                # *p_port* updates
                
                # if p_port is starting this frame...
                if p_port.status == NOT_STARTED and t >= 1.75-frameTolerance:
                    # keep track of start time/frame for later
                    p_port.frameNStart = frameN  # exact frame index
                    p_port.tStart = t  # local t and not account for scr refresh
                    p_port.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(p_port, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.addData('p_port.started', t)
                    # update status
                    p_port.status = STARTED
                    p_port.status = STARTED
                    win.callOnFlip(p_port.setData, int(1))
                
                # if p_port is stopping this frame...
                if p_port.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > p_port.tStartRefresh + .1-frameTolerance:
                        # keep track of stop time/frame for later
                        p_port.tStop = t  # not accounting for scr refresh
                        p_port.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.addData('p_port.stopped', t)
                        # update status
                        p_port.status = FINISHED
                        win.callOnFlip(p_port.setData, int(0))
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in CS_USComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "CS_US" ---
            for thisComponent in CS_USComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('CS_US.stopped', globalClock.getTime())
            if p_port.status == STARTED:
                win.callOnFlip(p_port.setData, int(0))
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-3.250000)
            
            # --- Prepare to start Routine "ITI" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('ITI.started', globalClock.getTime())
            # keep track of which components have finished
            ITIComponents = [iti]
            for thisComponent in ITIComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "ITI" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *iti* updates
                
                # if iti is starting this frame...
                if iti.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    iti.frameNStart = frameN  # exact frame index
                    iti.tStart = t  # local t and not account for scr refresh
                    iti.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(iti, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'iti.started')
                    # update status
                    iti.status = STARTED
                    iti.setAutoDraw(True)
                
                # if iti is active this frame...
                if iti.status == STARTED:
                    # update params
                    pass
                
                # if iti is stopping this frame...
                if iti.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > iti.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        iti.tStop = t  # not accounting for scr refresh
                        iti.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'iti.stopped')
                        # update status
                        iti.status = FINISHED
                        iti.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in ITIComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "ITI" ---
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('ITI.stopped', globalClock.getTime())
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='US') repeats of 'US_trigger'
        
        
        # set up handler to look after randomisation of conditions etc
        buffers_trials = data.TrialHandler(nReps=int(trial_type_acq=='E'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='buffers_trials')
        thisExp.addLoop(buffers_trials)  # add the loop to the experiment
        thisBuffers_trial = buffers_trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisBuffers_trial.rgb)
        if thisBuffers_trial != None:
            for paramName in thisBuffers_trial:
                globals()[paramName] = thisBuffers_trial[paramName]
        
        for thisBuffers_trial in buffers_trials:
            currentLoop = buffers_trials
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisBuffers_trial.rgb)
            if thisBuffers_trial != None:
                for paramName in thisBuffers_trial:
                    globals()[paramName] = thisBuffers_trial[paramName]
            
            # set up handler to look after randomisation of conditions etc
            buff_trials = data.TrialHandler(nReps=itemNo_oeLength_acq, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=[None],
                seed=None, name='buff_trials')
            thisExp.addLoop(buff_trials)  # add the loop to the experiment
            thisBuff_trial = buff_trials.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisBuff_trial.rgb)
            if thisBuff_trial != None:
                for paramName in thisBuff_trial:
                    globals()[paramName] = thisBuff_trial[paramName]
            
            for thisBuff_trial in buff_trials:
                currentLoop = buff_trials
                thisExp.timestampOnFlip(win, 'thisRow.t')
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        inputs=inputs, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                )
                # abbreviate parameter names if possible (e.g. rgb = thisBuff_trial.rgb)
                if thisBuff_trial != None:
                    for paramName in thisBuff_trial:
                        globals()[paramName] = thisBuff_trial[paramName]
                
                # --- Prepare to start Routine "buffer_new" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('buffer_new.started', globalClock.getTime())
                # Run 'Begin Routine' code from code_2
                # import random for generating numbers 
                import random 
                
                # generate values for coherence, speed and direction - for RDKs
                coherence_vals = round(random.uniform(0.4, .9), 1)
                speed_vals = round(random.uniform(0.01, 0.03), 2)
                direction_vals = random.choice([0, 180])
                
                # store values 
                thisExp.addData('coherence_value',coherence_vals)
                thisExp.addData('speed_value',speed_vals)
                thisExp.addData('direction_value',direction_vals)
                dots.setDir(direction_vals)
                dots.setSpeed(speed_vals)
                dots.setFieldCoherence(coherence_vals)
                dots.refreshDots()
                buff_resp.keys = []
                buff_resp.rt = []
                _buff_resp_allKeys = []
                late_buff_response.keys = []
                late_buff_response.rt = []
                _late_buff_response_allKeys = []
                # keep track of which components have finished
                buffer_newComponents = [pre_cue, dots, fixation, buff_buttons, buff_resp, late_buff_response]
                for thisComponent in buffer_newComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "buffer_new" ---
                routineForceEnded = not continueRoutine
                while continueRoutine and routineTimer.getTime() < 1.7:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *pre_cue* updates
                    
                    # if pre_cue is starting this frame...
                    if pre_cue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        pre_cue.frameNStart = frameN  # exact frame index
                        pre_cue.tStart = t  # local t and not account for scr refresh
                        pre_cue.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(pre_cue, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'pre_cue.started')
                        # update status
                        pre_cue.status = STARTED
                        pre_cue.setAutoDraw(True)
                    
                    # if pre_cue is active this frame...
                    if pre_cue.status == STARTED:
                        # update params
                        pass
                    
                    # if pre_cue is stopping this frame...
                    if pre_cue.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > pre_cue.tStartRefresh + 1.7-frameTolerance:
                            # keep track of stop time/frame for later
                            pre_cue.tStop = t  # not accounting for scr refresh
                            pre_cue.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'pre_cue.stopped')
                            # update status
                            pre_cue.status = FINISHED
                            pre_cue.setAutoDraw(False)
                    
                    # *dots* updates
                    
                    # if dots is starting this frame...
                    if dots.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        dots.frameNStart = frameN  # exact frame index
                        dots.tStart = t  # local t and not account for scr refresh
                        dots.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(dots, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'dots.started')
                        # update status
                        dots.status = STARTED
                        dots.setAutoDraw(True)
                    
                    # if dots is active this frame...
                    if dots.status == STARTED:
                        # update params
                        pass
                    
                    # if dots is stopping this frame...
                    if dots.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > dots.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            dots.tStop = t  # not accounting for scr refresh
                            dots.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'dots.stopped')
                            # update status
                            dots.status = FINISHED
                            dots.setAutoDraw(False)
                    
                    # *fixation* updates
                    
                    # if fixation is starting this frame...
                    if fixation.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        fixation.frameNStart = frameN  # exact frame index
                        fixation.tStart = t  # local t and not account for scr refresh
                        fixation.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fixation.started')
                        # update status
                        fixation.status = STARTED
                        fixation.setAutoDraw(True)
                    
                    # if fixation is active this frame...
                    if fixation.status == STARTED:
                        # update params
                        pass
                    
                    # if fixation is stopping this frame...
                    if fixation.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > fixation.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            fixation.tStop = t  # not accounting for scr refresh
                            fixation.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'fixation.stopped')
                            # update status
                            fixation.status = FINISHED
                            fixation.setAutoDraw(False)
                    
                    # *buff_buttons* updates
                    
                    # if buff_buttons is starting this frame...
                    if buff_buttons.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        buff_buttons.frameNStart = frameN  # exact frame index
                        buff_buttons.tStart = t  # local t and not account for scr refresh
                        buff_buttons.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(buff_buttons, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'buff_buttons.started')
                        # update status
                        buff_buttons.status = STARTED
                        buff_buttons.setAutoDraw(True)
                    
                    # if buff_buttons is active this frame...
                    if buff_buttons.status == STARTED:
                        # update params
                        pass
                    
                    # if buff_buttons is stopping this frame...
                    if buff_buttons.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > buff_buttons.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            buff_buttons.tStop = t  # not accounting for scr refresh
                            buff_buttons.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'buff_buttons.stopped')
                            # update status
                            buff_buttons.status = FINISHED
                            buff_buttons.setAutoDraw(False)
                    
                    # *buff_resp* updates
                    waitOnFlip = False
                    
                    # if buff_resp is starting this frame...
                    if buff_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        buff_resp.frameNStart = frameN  # exact frame index
                        buff_resp.tStart = t  # local t and not account for scr refresh
                        buff_resp.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(buff_resp, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'buff_resp.started')
                        # update status
                        buff_resp.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(buff_resp.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(buff_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if buff_resp is stopping this frame...
                    if buff_resp.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > buff_resp.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            buff_resp.tStop = t  # not accounting for scr refresh
                            buff_resp.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'buff_resp.stopped')
                            # update status
                            buff_resp.status = FINISHED
                            buff_resp.status = FINISHED
                    if buff_resp.status == STARTED and not waitOnFlip:
                        theseKeys = buff_resp.getKeys(keyList=['1', '2'], ignoreKeys=["escape"], waitRelease=False)
                        _buff_resp_allKeys.extend(theseKeys)
                        if len(_buff_resp_allKeys):
                            buff_resp.keys = _buff_resp_allKeys[-1].name  # just the last key pressed
                            buff_resp.rt = _buff_resp_allKeys[-1].rt
                            buff_resp.duration = _buff_resp_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *late_buff_response* updates
                    waitOnFlip = False
                    
                    # if late_buff_response is starting this frame...
                    if late_buff_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        late_buff_response.frameNStart = frameN  # exact frame index
                        late_buff_response.tStart = t  # local t and not account for scr refresh
                        late_buff_response.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(late_buff_response, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'late_buff_response.started')
                        # update status
                        late_buff_response.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(late_buff_response.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(late_buff_response.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if late_buff_response is stopping this frame...
                    if late_buff_response.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > late_buff_response.tStartRefresh + .5-frameTolerance:
                            # keep track of stop time/frame for later
                            late_buff_response.tStop = t  # not accounting for scr refresh
                            late_buff_response.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'late_buff_response.stopped')
                            # update status
                            late_buff_response.status = FINISHED
                            late_buff_response.status = FINISHED
                    if late_buff_response.status == STARTED and not waitOnFlip:
                        theseKeys = late_buff_response.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                        _late_buff_response_allKeys.extend(theseKeys)
                        if len(_late_buff_response_allKeys):
                            late_buff_response.keys = _late_buff_response_allKeys[-1].name  # just the last key pressed
                            late_buff_response.rt = _late_buff_response_allKeys[-1].rt
                            late_buff_response.duration = _late_buff_response_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in buffer_newComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "buffer_new" ---
                for thisComponent in buffer_newComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('buffer_new.stopped', globalClock.getTime())
                # Run 'End Routine' code from code_2
                trial_accuracy = 0  # Default accuracy is 0
                
                if buff_resp.keys == '1':
                    if direction_vals == 180:
                        trial_accuracy = 1
                elif buff_resp.keys == '2':
                    if direction_vals == 0:
                        trial_accuracy = 1
                
                thisExp.addData('buffer_acc', trial_accuracy)
                # check responses
                if buff_resp.keys in ['', [], None]:  # No response was made
                    buff_resp.keys = None
                buff_trials.addData('buff_resp.keys',buff_resp.keys)
                if buff_resp.keys != None:  # we had a response
                    buff_trials.addData('buff_resp.rt', buff_resp.rt)
                    buff_trials.addData('buff_resp.duration', buff_resp.duration)
                # check responses
                if late_buff_response.keys in ['', [], None]:  # No response was made
                    late_buff_response.keys = None
                buff_trials.addData('late_buff_response.keys',late_buff_response.keys)
                if late_buff_response.keys != None:  # we had a response
                    buff_trials.addData('late_buff_response.rt', late_buff_response.rt)
                    buff_trials.addData('late_buff_response.duration', late_buff_response.duration)
                # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
                if routineForceEnded:
                    routineTimer.reset()
                else:
                    routineTimer.addTime(-1.700000)
                thisExp.nextEntry()
                
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
            # completed itemNo_oeLength_acq repeats of 'buff_trials'
            
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='E') repeats of 'buffers_trials'
        
        
        # set up handler to look after randomisation of conditions etc
        byst_trials = data.TrialHandler(nReps=int(trial_type_acq=='RR' or trial_type_acq=='RS' or trial_type_acq=='SR' or trial_type_acq=='SS' or trial_type_acq=='FF'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='byst_trials')
        thisExp.addLoop(byst_trials)  # add the loop to the experiment
        thisByst_trial = byst_trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisByst_trial.rgb)
        if thisByst_trial != None:
            for paramName in thisByst_trial:
                globals()[paramName] = thisByst_trial[paramName]
        
        for thisByst_trial in byst_trials:
            currentLoop = byst_trials
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisByst_trial.rgb)
            if thisByst_trial != None:
                for paramName in thisByst_trial:
                    globals()[paramName] = thisByst_trial[paramName]
            
            # --- Prepare to start Routine "bystander" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('bystander.started', globalClock.getTime())
            bystander_image_ext.setImage(image_acq)
            byst_resp_acq.keys = []
            byst_resp_acq.rt = []
            _byst_resp_acq_allKeys = []
            byst_earlyresp_acq.keys = []
            byst_earlyresp_acq.rt = []
            _byst_earlyresp_acq_allKeys = []
            # keep track of which components have finished
            bystanderComponents = [bystander_precue_3, bystander_image_ext, byst_resp_acq, byst_buttons_ext, byst_earlyresp_acq]
            for thisComponent in bystanderComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "bystander" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 5.5:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *bystander_precue_3* updates
                
                # if bystander_precue_3 is starting this frame...
                if bystander_precue_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    bystander_precue_3.frameNStart = frameN  # exact frame index
                    bystander_precue_3.tStart = t  # local t and not account for scr refresh
                    bystander_precue_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(bystander_precue_3, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'bystander_precue_3.started')
                    # update status
                    bystander_precue_3.status = STARTED
                    bystander_precue_3.setAutoDraw(True)
                
                # if bystander_precue_3 is active this frame...
                if bystander_precue_3.status == STARTED:
                    # update params
                    pass
                
                # if bystander_precue_3 is stopping this frame...
                if bystander_precue_3.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > bystander_precue_3.tStartRefresh + 5.5-frameTolerance:
                        # keep track of stop time/frame for later
                        bystander_precue_3.tStop = t  # not accounting for scr refresh
                        bystander_precue_3.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'bystander_precue_3.stopped')
                        # update status
                        bystander_precue_3.status = FINISHED
                        bystander_precue_3.setAutoDraw(False)
                
                # *bystander_image_ext* updates
                
                # if bystander_image_ext is starting this frame...
                if bystander_image_ext.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    bystander_image_ext.frameNStart = frameN  # exact frame index
                    bystander_image_ext.tStart = t  # local t and not account for scr refresh
                    bystander_image_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(bystander_image_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'bystander_image_ext.started')
                    # update status
                    bystander_image_ext.status = STARTED
                    bystander_image_ext.setAutoDraw(True)
                
                # if bystander_image_ext is active this frame...
                if bystander_image_ext.status == STARTED:
                    # update params
                    pass
                
                # if bystander_image_ext is stopping this frame...
                if bystander_image_ext.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > bystander_image_ext.tStartRefresh + 5.0-frameTolerance:
                        # keep track of stop time/frame for later
                        bystander_image_ext.tStop = t  # not accounting for scr refresh
                        bystander_image_ext.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'bystander_image_ext.stopped')
                        # update status
                        bystander_image_ext.status = FINISHED
                        bystander_image_ext.setAutoDraw(False)
                
                # *byst_resp_acq* updates
                waitOnFlip = False
                
                # if byst_resp_acq is starting this frame...
                if byst_resp_acq.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    byst_resp_acq.frameNStart = frameN  # exact frame index
                    byst_resp_acq.tStart = t  # local t and not account for scr refresh
                    byst_resp_acq.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(byst_resp_acq, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_resp_acq.started')
                    # update status
                    byst_resp_acq.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(byst_resp_acq.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(byst_resp_acq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                
                # if byst_resp_acq is stopping this frame...
                if byst_resp_acq.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > byst_resp_acq.tStartRefresh + 3-frameTolerance:
                        # keep track of stop time/frame for later
                        byst_resp_acq.tStop = t  # not accounting for scr refresh
                        byst_resp_acq.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'byst_resp_acq.stopped')
                        # update status
                        byst_resp_acq.status = FINISHED
                        byst_resp_acq.status = FINISHED
                if byst_resp_acq.status == STARTED and not waitOnFlip:
                    theseKeys = byst_resp_acq.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                    _byst_resp_acq_allKeys.extend(theseKeys)
                    if len(_byst_resp_acq_allKeys):
                        byst_resp_acq.keys = _byst_resp_acq_allKeys[-1].name  # just the last key pressed
                        byst_resp_acq.rt = _byst_resp_acq_allKeys[-1].rt
                        byst_resp_acq.duration = _byst_resp_acq_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *byst_buttons_ext* updates
                
                # if byst_buttons_ext is starting this frame...
                if byst_buttons_ext.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    byst_buttons_ext.frameNStart = frameN  # exact frame index
                    byst_buttons_ext.tStart = t  # local t and not account for scr refresh
                    byst_buttons_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(byst_buttons_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_buttons_ext.started')
                    # update status
                    byst_buttons_ext.status = STARTED
                    byst_buttons_ext.setAutoDraw(True)
                
                # if byst_buttons_ext is active this frame...
                if byst_buttons_ext.status == STARTED:
                    # update params
                    pass
                
                # if byst_buttons_ext is stopping this frame...
                if byst_buttons_ext.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > byst_buttons_ext.tStartRefresh + 5-frameTolerance:
                        # keep track of stop time/frame for later
                        byst_buttons_ext.tStop = t  # not accounting for scr refresh
                        byst_buttons_ext.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'byst_buttons_ext.stopped')
                        # update status
                        byst_buttons_ext.status = FINISHED
                        byst_buttons_ext.setAutoDraw(False)
                
                # *byst_earlyresp_acq* updates
                waitOnFlip = False
                
                # if byst_earlyresp_acq is starting this frame...
                if byst_earlyresp_acq.status == NOT_STARTED and tThisFlip >= .2-frameTolerance:
                    # keep track of start time/frame for later
                    byst_earlyresp_acq.frameNStart = frameN  # exact frame index
                    byst_earlyresp_acq.tStart = t  # local t and not account for scr refresh
                    byst_earlyresp_acq.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(byst_earlyresp_acq, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_earlyresp_acq.started')
                    # update status
                    byst_earlyresp_acq.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(byst_earlyresp_acq.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(byst_earlyresp_acq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                
                # if byst_earlyresp_acq is stopping this frame...
                if byst_earlyresp_acq.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > byst_earlyresp_acq.tStartRefresh + 2.3-frameTolerance:
                        # keep track of stop time/frame for later
                        byst_earlyresp_acq.tStop = t  # not accounting for scr refresh
                        byst_earlyresp_acq.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'byst_earlyresp_acq.stopped')
                        # update status
                        byst_earlyresp_acq.status = FINISHED
                        byst_earlyresp_acq.status = FINISHED
                if byst_earlyresp_acq.status == STARTED and not waitOnFlip:
                    theseKeys = byst_earlyresp_acq.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                    _byst_earlyresp_acq_allKeys.extend(theseKeys)
                    if len(_byst_earlyresp_acq_allKeys):
                        byst_earlyresp_acq.keys = _byst_earlyresp_acq_allKeys[-1].name  # just the last key pressed
                        byst_earlyresp_acq.rt = _byst_earlyresp_acq_allKeys[-1].rt
                        byst_earlyresp_acq.duration = _byst_earlyresp_acq_allKeys[-1].duration
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in bystanderComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "bystander" ---
            for thisComponent in bystanderComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('bystander.stopped', globalClock.getTime())
            # check responses
            if byst_resp_acq.keys in ['', [], None]:  # No response was made
                byst_resp_acq.keys = None
            byst_trials.addData('byst_resp_acq.keys',byst_resp_acq.keys)
            if byst_resp_acq.keys != None:  # we had a response
                byst_trials.addData('byst_resp_acq.rt', byst_resp_acq.rt)
                byst_trials.addData('byst_resp_acq.duration', byst_resp_acq.duration)
            # check responses
            if byst_earlyresp_acq.keys in ['', [], None]:  # No response was made
                byst_earlyresp_acq.keys = None
            byst_trials.addData('byst_earlyresp_acq.keys',byst_earlyresp_acq.keys)
            if byst_earlyresp_acq.keys != None:  # we had a response
                byst_trials.addData('byst_earlyresp_acq.rt', byst_earlyresp_acq.rt)
                byst_trials.addData('byst_earlyresp_acq.duration', byst_earlyresp_acq.duration)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-5.500000)
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='RR' or trial_type_acq=='RS' or trial_type_acq=='SR' or trial_type_acq=='SS' or trial_type_acq=='FF') repeats of 'byst_trials'
        
        
        # set up handler to look after randomisation of conditions etc
        exp_rating = data.TrialHandler(nReps=int(trial_type_acq=='EXP'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='exp_rating')
        thisExp.addLoop(exp_rating)  # add the loop to the experiment
        thisExp_rating = exp_rating.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisExp_rating.rgb)
        if thisExp_rating != None:
            for paramName in thisExp_rating:
                globals()[paramName] = thisExp_rating[paramName]
        
        for thisExp_rating in exp_rating:
            currentLoop = exp_rating
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisExp_rating.rgb)
            if thisExp_rating != None:
                for paramName in thisExp_rating:
                    globals()[paramName] = thisExp_rating[paramName]
            
            # --- Prepare to start Routine "EXP_acq" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('EXP_acq.started', globalClock.getTime())
            expect_txt.setText('When you see this shape, \ndo you EXPECT an electric shock? ')
            slider_3.reset()
            exp_resp_acq.keys = []
            exp_resp_acq.rt = []
            _exp_resp_acq_allKeys = []
            CS_stim_4.setPos([0, 0])
            CS_stim_4.setImage(image_acq)
            # keep track of which components have finished
            EXP_acqComponents = [expect_txt, slider_3, exp_resp_acq, expect_rating, CS_stim_4]
            for thisComponent in EXP_acqComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "EXP_acq" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *expect_txt* updates
                
                # if expect_txt is starting this frame...
                if expect_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    expect_txt.frameNStart = frameN  # exact frame index
                    expect_txt.tStart = t  # local t and not account for scr refresh
                    expect_txt.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(expect_txt, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'expect_txt.started')
                    # update status
                    expect_txt.status = STARTED
                    expect_txt.setAutoDraw(True)
                
                # if expect_txt is active this frame...
                if expect_txt.status == STARTED:
                    # update params
                    pass
                
                # *slider_3* updates
                
                # if slider_3 is starting this frame...
                if slider_3.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    slider_3.frameNStart = frameN  # exact frame index
                    slider_3.tStart = t  # local t and not account for scr refresh
                    slider_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(slider_3, 'tStartRefresh')  # time at next scr refresh
                    # update status
                    slider_3.status = STARTED
                    slider_3.setAutoDraw(True)
                
                # if slider_3 is active this frame...
                if slider_3.status == STARTED:
                    # update params
                    pass
                
                # *exp_resp_acq* updates
                waitOnFlip = False
                
                # if exp_resp_acq is starting this frame...
                if exp_resp_acq.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                    # keep track of start time/frame for later
                    exp_resp_acq.frameNStart = frameN  # exact frame index
                    exp_resp_acq.tStart = t  # local t and not account for scr refresh
                    exp_resp_acq.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(exp_resp_acq, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'exp_resp_acq.started')
                    # update status
                    exp_resp_acq.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(exp_resp_acq.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(exp_resp_acq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if exp_resp_acq.status == STARTED and not waitOnFlip:
                    theseKeys = exp_resp_acq.getKeys(keyList=['1','2','3','4','5'], ignoreKeys=["escape"], waitRelease=False)
                    _exp_resp_acq_allKeys.extend(theseKeys)
                    if len(_exp_resp_acq_allKeys):
                        exp_resp_acq.keys = _exp_resp_acq_allKeys[-1].name  # just the last key pressed
                        exp_resp_acq.rt = _exp_resp_acq_allKeys[-1].rt
                        exp_resp_acq.duration = _exp_resp_acq_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *expect_rating* updates
                
                # if expect_rating is starting this frame...
                if expect_rating.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    expect_rating.frameNStart = frameN  # exact frame index
                    expect_rating.tStart = t  # local t and not account for scr refresh
                    expect_rating.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(expect_rating, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'expect_rating.started')
                    # update status
                    expect_rating.status = STARTED
                    expect_rating.setAutoDraw(True)
                
                # if expect_rating is active this frame...
                if expect_rating.status == STARTED:
                    # update params
                    pass
                
                # *CS_stim_4* updates
                
                # if CS_stim_4 is starting this frame...
                if CS_stim_4.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_4.frameNStart = frameN  # exact frame index
                    CS_stim_4.tStart = t  # local t and not account for scr refresh
                    CS_stim_4.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_4, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_4.started')
                    # update status
                    CS_stim_4.status = STARTED
                    CS_stim_4.setAutoDraw(True)
                
                # if CS_stim_4 is active this frame...
                if CS_stim_4.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in EXP_acqComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "EXP_acq" ---
            for thisComponent in EXP_acqComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('EXP_acq.stopped', globalClock.getTime())
            exp_rating.addData('slider_3.response', slider_3.getRating())
            exp_rating.addData('slider_3.history', slider_3.getHistory())
            # check responses
            if exp_resp_acq.keys in ['', [], None]:  # No response was made
                exp_resp_acq.keys = None
            exp_rating.addData('exp_resp_acq.keys',exp_resp_acq.keys)
            if exp_resp_acq.keys != None:  # we had a response
                exp_rating.addData('exp_resp_acq.rt', exp_resp_acq.rt)
                exp_rating.addData('exp_resp_acq.duration', exp_resp_acq.duration)
            # the Routine "EXP_acq" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='EXP') repeats of 'exp_rating'
        
        
        # set up handler to look after randomisation of conditions etc
        val_rating = data.TrialHandler(nReps=int(trial_type_acq=='VAL'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='val_rating')
        thisExp.addLoop(val_rating)  # add the loop to the experiment
        thisVal_rating = val_rating.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisVal_rating.rgb)
        if thisVal_rating != None:
            for paramName in thisVal_rating:
                globals()[paramName] = thisVal_rating[paramName]
        
        for thisVal_rating in val_rating:
            currentLoop = val_rating
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisVal_rating.rgb)
            if thisVal_rating != None:
                for paramName in thisVal_rating:
                    globals()[paramName] = thisVal_rating[paramName]
            
            # --- Prepare to start Routine "VAL_acq" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('VAL_acq.started', globalClock.getTime())
            val_text.setText('When you see this shape, \nhow POSITIVE / NEGATIVE do you feel? ')
            resp_val_acq.keys = []
            resp_val_acq.rt = []
            _resp_val_acq_allKeys = []
            CS_stim_6.setPos([0, 0])
            CS_stim_6.setImage(image_acq)
            # keep track of which components have finished
            VAL_acqComponents = [val_text, SAM_val, resp_val_acq, CS_stim_6]
            for thisComponent in VAL_acqComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "VAL_acq" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *val_text* updates
                
                # if val_text is starting this frame...
                if val_text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    val_text.frameNStart = frameN  # exact frame index
                    val_text.tStart = t  # local t and not account for scr refresh
                    val_text.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(val_text, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'val_text.started')
                    # update status
                    val_text.status = STARTED
                    val_text.setAutoDraw(True)
                
                # if val_text is active this frame...
                if val_text.status == STARTED:
                    # update params
                    pass
                
                # *SAM_val* updates
                
                # if SAM_val is starting this frame...
                if SAM_val.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    SAM_val.frameNStart = frameN  # exact frame index
                    SAM_val.tStart = t  # local t and not account for scr refresh
                    SAM_val.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(SAM_val, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'SAM_val.started')
                    # update status
                    SAM_val.status = STARTED
                    SAM_val.setAutoDraw(True)
                
                # if SAM_val is active this frame...
                if SAM_val.status == STARTED:
                    # update params
                    pass
                
                # *resp_val_acq* updates
                waitOnFlip = False
                
                # if resp_val_acq is starting this frame...
                if resp_val_acq.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                    # keep track of start time/frame for later
                    resp_val_acq.frameNStart = frameN  # exact frame index
                    resp_val_acq.tStart = t  # local t and not account for scr refresh
                    resp_val_acq.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(resp_val_acq, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp_val_acq.started')
                    # update status
                    resp_val_acq.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(resp_val_acq.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(resp_val_acq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if resp_val_acq.status == STARTED and not waitOnFlip:
                    theseKeys = resp_val_acq.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                    _resp_val_acq_allKeys.extend(theseKeys)
                    if len(_resp_val_acq_allKeys):
                        resp_val_acq.keys = _resp_val_acq_allKeys[-1].name  # just the last key pressed
                        resp_val_acq.rt = _resp_val_acq_allKeys[-1].rt
                        resp_val_acq.duration = _resp_val_acq_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *CS_stim_6* updates
                
                # if CS_stim_6 is starting this frame...
                if CS_stim_6.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_6.frameNStart = frameN  # exact frame index
                    CS_stim_6.tStart = t  # local t and not account for scr refresh
                    CS_stim_6.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_6, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_6.started')
                    # update status
                    CS_stim_6.status = STARTED
                    CS_stim_6.setAutoDraw(True)
                
                # if CS_stim_6 is active this frame...
                if CS_stim_6.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in VAL_acqComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "VAL_acq" ---
            for thisComponent in VAL_acqComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('VAL_acq.stopped', globalClock.getTime())
            # check responses
            if resp_val_acq.keys in ['', [], None]:  # No response was made
                resp_val_acq.keys = None
            val_rating.addData('resp_val_acq.keys',resp_val_acq.keys)
            if resp_val_acq.keys != None:  # we had a response
                val_rating.addData('resp_val_acq.rt', resp_val_acq.rt)
                val_rating.addData('resp_val_acq.duration', resp_val_acq.duration)
            # the Routine "VAL_acq" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='VAL') repeats of 'val_rating'
        
        
        # set up handler to look after randomisation of conditions etc
        arsl_rating = data.TrialHandler(nReps=int(trial_type_acq=='ARSL'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='arsl_rating')
        thisExp.addLoop(arsl_rating)  # add the loop to the experiment
        thisArsl_rating = arsl_rating.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisArsl_rating.rgb)
        if thisArsl_rating != None:
            for paramName in thisArsl_rating:
                globals()[paramName] = thisArsl_rating[paramName]
        
        for thisArsl_rating in arsl_rating:
            currentLoop = arsl_rating
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisArsl_rating.rgb)
            if thisArsl_rating != None:
                for paramName in thisArsl_rating:
                    globals()[paramName] = thisArsl_rating[paramName]
            
            # --- Prepare to start Routine "ARSL_acq" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('ARSL_acq.started', globalClock.getTime())
            text_arsl.setText('When you see this shape, \nhow TENSE / CALM do you feel? ')
            resp_arsl_acq.keys = []
            resp_arsl_acq.rt = []
            _resp_arsl_acq_allKeys = []
            CS_stim_7.setPos([0, 0])
            CS_stim_7.setImage(image_acq)
            # keep track of which components have finished
            ARSL_acqComponents = [text_arsl, SAM_arsl, resp_arsl_acq, CS_stim_7]
            for thisComponent in ARSL_acqComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "ARSL_acq" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_arsl* updates
                
                # if text_arsl is starting this frame...
                if text_arsl.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    text_arsl.frameNStart = frameN  # exact frame index
                    text_arsl.tStart = t  # local t and not account for scr refresh
                    text_arsl.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_arsl, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_arsl.started')
                    # update status
                    text_arsl.status = STARTED
                    text_arsl.setAutoDraw(True)
                
                # if text_arsl is active this frame...
                if text_arsl.status == STARTED:
                    # update params
                    pass
                
                # *SAM_arsl* updates
                
                # if SAM_arsl is starting this frame...
                if SAM_arsl.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    SAM_arsl.frameNStart = frameN  # exact frame index
                    SAM_arsl.tStart = t  # local t and not account for scr refresh
                    SAM_arsl.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(SAM_arsl, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'SAM_arsl.started')
                    # update status
                    SAM_arsl.status = STARTED
                    SAM_arsl.setAutoDraw(True)
                
                # if SAM_arsl is active this frame...
                if SAM_arsl.status == STARTED:
                    # update params
                    pass
                
                # *resp_arsl_acq* updates
                waitOnFlip = False
                
                # if resp_arsl_acq is starting this frame...
                if resp_arsl_acq.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                    # keep track of start time/frame for later
                    resp_arsl_acq.frameNStart = frameN  # exact frame index
                    resp_arsl_acq.tStart = t  # local t and not account for scr refresh
                    resp_arsl_acq.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(resp_arsl_acq, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp_arsl_acq.started')
                    # update status
                    resp_arsl_acq.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(resp_arsl_acq.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(resp_arsl_acq.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if resp_arsl_acq.status == STARTED and not waitOnFlip:
                    theseKeys = resp_arsl_acq.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                    _resp_arsl_acq_allKeys.extend(theseKeys)
                    if len(_resp_arsl_acq_allKeys):
                        resp_arsl_acq.keys = _resp_arsl_acq_allKeys[-1].name  # just the last key pressed
                        resp_arsl_acq.rt = _resp_arsl_acq_allKeys[-1].rt
                        resp_arsl_acq.duration = _resp_arsl_acq_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *CS_stim_7* updates
                
                # if CS_stim_7 is starting this frame...
                if CS_stim_7.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_7.frameNStart = frameN  # exact frame index
                    CS_stim_7.tStart = t  # local t and not account for scr refresh
                    CS_stim_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_7.started')
                    # update status
                    CS_stim_7.status = STARTED
                    CS_stim_7.setAutoDraw(True)
                
                # if CS_stim_7 is active this frame...
                if CS_stim_7.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in ARSL_acqComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "ARSL_acq" ---
            for thisComponent in ARSL_acqComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('ARSL_acq.stopped', globalClock.getTime())
            # check responses
            if resp_arsl_acq.keys in ['', [], None]:  # No response was made
                resp_arsl_acq.keys = None
            arsl_rating.addData('resp_arsl_acq.keys',resp_arsl_acq.keys)
            if resp_arsl_acq.keys != None:  # we had a response
                arsl_rating.addData('resp_arsl_acq.rt', resp_arsl_acq.rt)
                arsl_rating.addData('resp_arsl_acq.duration', resp_arsl_acq.duration)
            # the Routine "ARSL_acq" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_acq=='ARSL') repeats of 'arsl_rating'
        
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'Acquisition'
    
    
    # set up handler to look after randomisation of conditions etc
    Extinction = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Extinction.xlsx'),
        seed=None, name='Extinction')
    thisExp.addLoop(Extinction)  # add the loop to the experiment
    thisExtinction = Extinction.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExtinction.rgb)
    if thisExtinction != None:
        for paramName in thisExtinction:
            globals()[paramName] = thisExtinction[paramName]
    
    for thisExtinction in Extinction:
        currentLoop = Extinction
        thisExp.timestampOnFlip(win, 'thisRow.t')
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                inputs=inputs, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisExtinction.rgb)
        if thisExtinction != None:
            for paramName in thisExtinction:
                globals()[paramName] = thisExtinction[paramName]
        
        # set up handler to look after randomisation of conditions etc
        trials = data.TrialHandler(nReps=int(trial_type_ext=='CSp' or trial_type_ext=='CSm'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trials')
        thisExp.addLoop(trials)  # add the loop to the experiment
        thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                globals()[paramName] = thisTrial[paramName]
        
        for thisTrial in trials:
            currentLoop = trials
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if thisTrial != None:
                for paramName in thisTrial:
                    globals()[paramName] = thisTrial[paramName]
            
            # --- Prepare to start Routine "CS_ext" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('CS_ext.started', globalClock.getTime())
            CS_stim_3.setPos([0, 0])
            CS_stim_3.setImage(image_ext)
            # keep track of which components have finished
            CS_extComponents = [CS_stim_3]
            for thisComponent in CS_extComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "CS_ext" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 3.25:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *CS_stim_3* updates
                
                # if CS_stim_3 is starting this frame...
                if CS_stim_3.status == NOT_STARTED and tThisFlip >= .750-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_3.frameNStart = frameN  # exact frame index
                    CS_stim_3.tStart = t  # local t and not account for scr refresh
                    CS_stim_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_3, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_3.started')
                    # update status
                    CS_stim_3.status = STARTED
                    CS_stim_3.setAutoDraw(True)
                
                # if CS_stim_3 is active this frame...
                if CS_stim_3.status == STARTED:
                    # update params
                    pass
                
                # if CS_stim_3 is stopping this frame...
                if CS_stim_3.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > CS_stim_3.tStartRefresh + 2.5-frameTolerance:
                        # keep track of stop time/frame for later
                        CS_stim_3.tStop = t  # not accounting for scr refresh
                        CS_stim_3.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'CS_stim_3.stopped')
                        # update status
                        CS_stim_3.status = FINISHED
                        CS_stim_3.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in CS_extComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "CS_ext" ---
            for thisComponent in CS_extComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('CS_ext.stopped', globalClock.getTime())
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-3.250000)
            
            # --- Prepare to start Routine "ITI" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('ITI.started', globalClock.getTime())
            # keep track of which components have finished
            ITIComponents = [iti]
            for thisComponent in ITIComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "ITI" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *iti* updates
                
                # if iti is starting this frame...
                if iti.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    iti.frameNStart = frameN  # exact frame index
                    iti.tStart = t  # local t and not account for scr refresh
                    iti.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(iti, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'iti.started')
                    # update status
                    iti.status = STARTED
                    iti.setAutoDraw(True)
                
                # if iti is active this frame...
                if iti.status == STARTED:
                    # update params
                    pass
                
                # if iti is stopping this frame...
                if iti.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > iti.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        iti.tStop = t  # not accounting for scr refresh
                        iti.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'iti.stopped')
                        # update status
                        iti.status = FINISHED
                        iti.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in ITIComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "ITI" ---
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('ITI.stopped', globalClock.getTime())
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_ext=='CSp' or trial_type_ext=='CSm') repeats of 'trials'
        
        
        # set up handler to look after randomisation of conditions etc
        trials_3 = data.TrialHandler(nReps=int(trial_type_ext=='E'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trials_3')
        thisExp.addLoop(trials_3)  # add the loop to the experiment
        thisTrial_3 = trials_3.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
        if thisTrial_3 != None:
            for paramName in thisTrial_3:
                globals()[paramName] = thisTrial_3[paramName]
        
        for thisTrial_3 in trials_3:
            currentLoop = trials_3
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
            if thisTrial_3 != None:
                for paramName in thisTrial_3:
                    globals()[paramName] = thisTrial_3[paramName]
            
            # set up handler to look after randomisation of conditions etc
            trials_2 = data.TrialHandler(nReps=itemNo_oeLength_ext, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=[None],
                seed=None, name='trials_2')
            thisExp.addLoop(trials_2)  # add the loop to the experiment
            thisTrial_2 = trials_2.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
            if thisTrial_2 != None:
                for paramName in thisTrial_2:
                    globals()[paramName] = thisTrial_2[paramName]
            
            for thisTrial_2 in trials_2:
                currentLoop = trials_2
                thisExp.timestampOnFlip(win, 'thisRow.t')
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        inputs=inputs, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                )
                # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
                if thisTrial_2 != None:
                    for paramName in thisTrial_2:
                        globals()[paramName] = thisTrial_2[paramName]
                
                # --- Prepare to start Routine "buffer_new" ---
                continueRoutine = True
                # update component parameters for each repeat
                thisExp.addData('buffer_new.started', globalClock.getTime())
                # Run 'Begin Routine' code from code_2
                # import random for generating numbers 
                import random 
                
                # generate values for coherence, speed and direction - for RDKs
                coherence_vals = round(random.uniform(0.4, .9), 1)
                speed_vals = round(random.uniform(0.01, 0.03), 2)
                direction_vals = random.choice([0, 180])
                
                # store values 
                thisExp.addData('coherence_value',coherence_vals)
                thisExp.addData('speed_value',speed_vals)
                thisExp.addData('direction_value',direction_vals)
                dots.setDir(direction_vals)
                dots.setSpeed(speed_vals)
                dots.setFieldCoherence(coherence_vals)
                dots.refreshDots()
                buff_resp.keys = []
                buff_resp.rt = []
                _buff_resp_allKeys = []
                late_buff_response.keys = []
                late_buff_response.rt = []
                _late_buff_response_allKeys = []
                # keep track of which components have finished
                buffer_newComponents = [pre_cue, dots, fixation, buff_buttons, buff_resp, late_buff_response]
                for thisComponent in buffer_newComponents:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "buffer_new" ---
                routineForceEnded = not continueRoutine
                while continueRoutine and routineTimer.getTime() < 1.7:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *pre_cue* updates
                    
                    # if pre_cue is starting this frame...
                    if pre_cue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        pre_cue.frameNStart = frameN  # exact frame index
                        pre_cue.tStart = t  # local t and not account for scr refresh
                        pre_cue.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(pre_cue, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'pre_cue.started')
                        # update status
                        pre_cue.status = STARTED
                        pre_cue.setAutoDraw(True)
                    
                    # if pre_cue is active this frame...
                    if pre_cue.status == STARTED:
                        # update params
                        pass
                    
                    # if pre_cue is stopping this frame...
                    if pre_cue.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > pre_cue.tStartRefresh + 1.7-frameTolerance:
                            # keep track of stop time/frame for later
                            pre_cue.tStop = t  # not accounting for scr refresh
                            pre_cue.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'pre_cue.stopped')
                            # update status
                            pre_cue.status = FINISHED
                            pre_cue.setAutoDraw(False)
                    
                    # *dots* updates
                    
                    # if dots is starting this frame...
                    if dots.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        dots.frameNStart = frameN  # exact frame index
                        dots.tStart = t  # local t and not account for scr refresh
                        dots.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(dots, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'dots.started')
                        # update status
                        dots.status = STARTED
                        dots.setAutoDraw(True)
                    
                    # if dots is active this frame...
                    if dots.status == STARTED:
                        # update params
                        pass
                    
                    # if dots is stopping this frame...
                    if dots.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > dots.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            dots.tStop = t  # not accounting for scr refresh
                            dots.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'dots.stopped')
                            # update status
                            dots.status = FINISHED
                            dots.setAutoDraw(False)
                    
                    # *fixation* updates
                    
                    # if fixation is starting this frame...
                    if fixation.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        fixation.frameNStart = frameN  # exact frame index
                        fixation.tStart = t  # local t and not account for scr refresh
                        fixation.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fixation.started')
                        # update status
                        fixation.status = STARTED
                        fixation.setAutoDraw(True)
                    
                    # if fixation is active this frame...
                    if fixation.status == STARTED:
                        # update params
                        pass
                    
                    # if fixation is stopping this frame...
                    if fixation.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > fixation.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            fixation.tStop = t  # not accounting for scr refresh
                            fixation.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'fixation.stopped')
                            # update status
                            fixation.status = FINISHED
                            fixation.setAutoDraw(False)
                    
                    # *buff_buttons* updates
                    
                    # if buff_buttons is starting this frame...
                    if buff_buttons.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        buff_buttons.frameNStart = frameN  # exact frame index
                        buff_buttons.tStart = t  # local t and not account for scr refresh
                        buff_buttons.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(buff_buttons, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'buff_buttons.started')
                        # update status
                        buff_buttons.status = STARTED
                        buff_buttons.setAutoDraw(True)
                    
                    # if buff_buttons is active this frame...
                    if buff_buttons.status == STARTED:
                        # update params
                        pass
                    
                    # if buff_buttons is stopping this frame...
                    if buff_buttons.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > buff_buttons.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            buff_buttons.tStop = t  # not accounting for scr refresh
                            buff_buttons.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'buff_buttons.stopped')
                            # update status
                            buff_buttons.status = FINISHED
                            buff_buttons.setAutoDraw(False)
                    
                    # *buff_resp* updates
                    waitOnFlip = False
                    
                    # if buff_resp is starting this frame...
                    if buff_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                        # keep track of start time/frame for later
                        buff_resp.frameNStart = frameN  # exact frame index
                        buff_resp.tStart = t  # local t and not account for scr refresh
                        buff_resp.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(buff_resp, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'buff_resp.started')
                        # update status
                        buff_resp.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(buff_resp.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(buff_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if buff_resp is stopping this frame...
                    if buff_resp.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > buff_resp.tStartRefresh + 1.2-frameTolerance:
                            # keep track of stop time/frame for later
                            buff_resp.tStop = t  # not accounting for scr refresh
                            buff_resp.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'buff_resp.stopped')
                            # update status
                            buff_resp.status = FINISHED
                            buff_resp.status = FINISHED
                    if buff_resp.status == STARTED and not waitOnFlip:
                        theseKeys = buff_resp.getKeys(keyList=['1', '2'], ignoreKeys=["escape"], waitRelease=False)
                        _buff_resp_allKeys.extend(theseKeys)
                        if len(_buff_resp_allKeys):
                            buff_resp.keys = _buff_resp_allKeys[-1].name  # just the last key pressed
                            buff_resp.rt = _buff_resp_allKeys[-1].rt
                            buff_resp.duration = _buff_resp_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # *late_buff_response* updates
                    waitOnFlip = False
                    
                    # if late_buff_response is starting this frame...
                    if late_buff_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        late_buff_response.frameNStart = frameN  # exact frame index
                        late_buff_response.tStart = t  # local t and not account for scr refresh
                        late_buff_response.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(late_buff_response, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'late_buff_response.started')
                        # update status
                        late_buff_response.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(late_buff_response.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(late_buff_response.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if late_buff_response is stopping this frame...
                    if late_buff_response.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > late_buff_response.tStartRefresh + .5-frameTolerance:
                            # keep track of stop time/frame for later
                            late_buff_response.tStop = t  # not accounting for scr refresh
                            late_buff_response.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'late_buff_response.stopped')
                            # update status
                            late_buff_response.status = FINISHED
                            late_buff_response.status = FINISHED
                    if late_buff_response.status == STARTED and not waitOnFlip:
                        theseKeys = late_buff_response.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                        _late_buff_response_allKeys.extend(theseKeys)
                        if len(_late_buff_response_allKeys):
                            late_buff_response.keys = _late_buff_response_allKeys[-1].name  # just the last key pressed
                            late_buff_response.rt = _late_buff_response_allKeys[-1].rt
                            late_buff_response.duration = _late_buff_response_allKeys[-1].duration
                            # a response ends the routine
                            continueRoutine = False
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, inputs=inputs, win=win)
                        return
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in buffer_newComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # --- Ending Routine "buffer_new" ---
                for thisComponent in buffer_newComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.addData('buffer_new.stopped', globalClock.getTime())
                # Run 'End Routine' code from code_2
                trial_accuracy = 0  # Default accuracy is 0
                
                if buff_resp.keys == '1':
                    if direction_vals == 180:
                        trial_accuracy = 1
                elif buff_resp.keys == '2':
                    if direction_vals == 0:
                        trial_accuracy = 1
                
                thisExp.addData('buffer_acc', trial_accuracy)
                # check responses
                if buff_resp.keys in ['', [], None]:  # No response was made
                    buff_resp.keys = None
                trials_2.addData('buff_resp.keys',buff_resp.keys)
                if buff_resp.keys != None:  # we had a response
                    trials_2.addData('buff_resp.rt', buff_resp.rt)
                    trials_2.addData('buff_resp.duration', buff_resp.duration)
                # check responses
                if late_buff_response.keys in ['', [], None]:  # No response was made
                    late_buff_response.keys = None
                trials_2.addData('late_buff_response.keys',late_buff_response.keys)
                if late_buff_response.keys != None:  # we had a response
                    trials_2.addData('late_buff_response.rt', late_buff_response.rt)
                    trials_2.addData('late_buff_response.duration', late_buff_response.duration)
                # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
                if routineForceEnded:
                    routineTimer.reset()
                else:
                    routineTimer.addTime(-1.700000)
                thisExp.nextEntry()
                
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
            # completed itemNo_oeLength_ext repeats of 'trials_2'
            
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_ext=='E') repeats of 'trials_3'
        
        
        # set up handler to look after randomisation of conditions etc
        trials_4 = data.TrialHandler(nReps=int(trial_type_ext=='RR' or trial_type_ext=='RS' or trial_type_ext=='SR' or trial_type_ext=='SS' or trial_type_ext=='FF'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trials_4')
        thisExp.addLoop(trials_4)  # add the loop to the experiment
        thisTrial_4 = trials_4.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
        if thisTrial_4 != None:
            for paramName in thisTrial_4:
                globals()[paramName] = thisTrial_4[paramName]
        
        for thisTrial_4 in trials_4:
            currentLoop = trials_4
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
            if thisTrial_4 != None:
                for paramName in thisTrial_4:
                    globals()[paramName] = thisTrial_4[paramName]
            
            # --- Prepare to start Routine "bystander_ext" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('bystander_ext.started', globalClock.getTime())
            bystander_image_ext_2.setImage(image_ext)
            byst_resp_ext.keys = []
            byst_resp_ext.rt = []
            _byst_resp_ext_allKeys = []
            byst_earlyresp_ext.keys = []
            byst_earlyresp_ext.rt = []
            _byst_earlyresp_ext_allKeys = []
            # keep track of which components have finished
            bystander_extComponents = [bystander_precue, bystander_image_ext_2, byst_resp_ext, byst_buttons_ext_2, byst_earlyresp_ext]
            for thisComponent in bystander_extComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "bystander_ext" ---
            routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 5.5:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *bystander_precue* updates
                
                # if bystander_precue is starting this frame...
                if bystander_precue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    bystander_precue.frameNStart = frameN  # exact frame index
                    bystander_precue.tStart = t  # local t and not account for scr refresh
                    bystander_precue.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(bystander_precue, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'bystander_precue.started')
                    # update status
                    bystander_precue.status = STARTED
                    bystander_precue.setAutoDraw(True)
                
                # if bystander_precue is active this frame...
                if bystander_precue.status == STARTED:
                    # update params
                    pass
                
                # if bystander_precue is stopping this frame...
                if bystander_precue.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > bystander_precue.tStartRefresh + 5.5-frameTolerance:
                        # keep track of stop time/frame for later
                        bystander_precue.tStop = t  # not accounting for scr refresh
                        bystander_precue.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'bystander_precue.stopped')
                        # update status
                        bystander_precue.status = FINISHED
                        bystander_precue.setAutoDraw(False)
                
                # *bystander_image_ext_2* updates
                
                # if bystander_image_ext_2 is starting this frame...
                if bystander_image_ext_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    bystander_image_ext_2.frameNStart = frameN  # exact frame index
                    bystander_image_ext_2.tStart = t  # local t and not account for scr refresh
                    bystander_image_ext_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(bystander_image_ext_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'bystander_image_ext_2.started')
                    # update status
                    bystander_image_ext_2.status = STARTED
                    bystander_image_ext_2.setAutoDraw(True)
                
                # if bystander_image_ext_2 is active this frame...
                if bystander_image_ext_2.status == STARTED:
                    # update params
                    pass
                
                # if bystander_image_ext_2 is stopping this frame...
                if bystander_image_ext_2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > bystander_image_ext_2.tStartRefresh + 5.0-frameTolerance:
                        # keep track of stop time/frame for later
                        bystander_image_ext_2.tStop = t  # not accounting for scr refresh
                        bystander_image_ext_2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'bystander_image_ext_2.stopped')
                        # update status
                        bystander_image_ext_2.status = FINISHED
                        bystander_image_ext_2.setAutoDraw(False)
                
                # *byst_resp_ext* updates
                waitOnFlip = False
                
                # if byst_resp_ext is starting this frame...
                if byst_resp_ext.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    byst_resp_ext.frameNStart = frameN  # exact frame index
                    byst_resp_ext.tStart = t  # local t and not account for scr refresh
                    byst_resp_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(byst_resp_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_resp_ext.started')
                    # update status
                    byst_resp_ext.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(byst_resp_ext.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(byst_resp_ext.clearEvents, eventType='keyboard')  # clear events on next screen flip
                
                # if byst_resp_ext is stopping this frame...
                if byst_resp_ext.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > byst_resp_ext.tStartRefresh + 3-frameTolerance:
                        # keep track of stop time/frame for later
                        byst_resp_ext.tStop = t  # not accounting for scr refresh
                        byst_resp_ext.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'byst_resp_ext.stopped')
                        # update status
                        byst_resp_ext.status = FINISHED
                        byst_resp_ext.status = FINISHED
                if byst_resp_ext.status == STARTED and not waitOnFlip:
                    theseKeys = byst_resp_ext.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                    _byst_resp_ext_allKeys.extend(theseKeys)
                    if len(_byst_resp_ext_allKeys):
                        byst_resp_ext.keys = _byst_resp_ext_allKeys[-1].name  # just the last key pressed
                        byst_resp_ext.rt = _byst_resp_ext_allKeys[-1].rt
                        byst_resp_ext.duration = _byst_resp_ext_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *byst_buttons_ext_2* updates
                
                # if byst_buttons_ext_2 is starting this frame...
                if byst_buttons_ext_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    byst_buttons_ext_2.frameNStart = frameN  # exact frame index
                    byst_buttons_ext_2.tStart = t  # local t and not account for scr refresh
                    byst_buttons_ext_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(byst_buttons_ext_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_buttons_ext_2.started')
                    # update status
                    byst_buttons_ext_2.status = STARTED
                    byst_buttons_ext_2.setAutoDraw(True)
                
                # if byst_buttons_ext_2 is active this frame...
                if byst_buttons_ext_2.status == STARTED:
                    # update params
                    pass
                
                # if byst_buttons_ext_2 is stopping this frame...
                if byst_buttons_ext_2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > byst_buttons_ext_2.tStartRefresh + 5-frameTolerance:
                        # keep track of stop time/frame for later
                        byst_buttons_ext_2.tStop = t  # not accounting for scr refresh
                        byst_buttons_ext_2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'byst_buttons_ext_2.stopped')
                        # update status
                        byst_buttons_ext_2.status = FINISHED
                        byst_buttons_ext_2.setAutoDraw(False)
                
                # *byst_earlyresp_ext* updates
                waitOnFlip = False
                
                # if byst_earlyresp_ext is starting this frame...
                if byst_earlyresp_ext.status == NOT_STARTED and tThisFlip >= .2-frameTolerance:
                    # keep track of start time/frame for later
                    byst_earlyresp_ext.frameNStart = frameN  # exact frame index
                    byst_earlyresp_ext.tStart = t  # local t and not account for scr refresh
                    byst_earlyresp_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(byst_earlyresp_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'byst_earlyresp_ext.started')
                    # update status
                    byst_earlyresp_ext.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(byst_earlyresp_ext.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(byst_earlyresp_ext.clearEvents, eventType='keyboard')  # clear events on next screen flip
                
                # if byst_earlyresp_ext is stopping this frame...
                if byst_earlyresp_ext.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > byst_earlyresp_ext.tStartRefresh + 2.3-frameTolerance:
                        # keep track of stop time/frame for later
                        byst_earlyresp_ext.tStop = t  # not accounting for scr refresh
                        byst_earlyresp_ext.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'byst_earlyresp_ext.stopped')
                        # update status
                        byst_earlyresp_ext.status = FINISHED
                        byst_earlyresp_ext.status = FINISHED
                if byst_earlyresp_ext.status == STARTED and not waitOnFlip:
                    theseKeys = byst_earlyresp_ext.getKeys(keyList=['1','2'], ignoreKeys=["escape"], waitRelease=False)
                    _byst_earlyresp_ext_allKeys.extend(theseKeys)
                    if len(_byst_earlyresp_ext_allKeys):
                        byst_earlyresp_ext.keys = _byst_earlyresp_ext_allKeys[-1].name  # just the last key pressed
                        byst_earlyresp_ext.rt = _byst_earlyresp_ext_allKeys[-1].rt
                        byst_earlyresp_ext.duration = _byst_earlyresp_ext_allKeys[-1].duration
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in bystander_extComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "bystander_ext" ---
            for thisComponent in bystander_extComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('bystander_ext.stopped', globalClock.getTime())
            # check responses
            if byst_resp_ext.keys in ['', [], None]:  # No response was made
                byst_resp_ext.keys = None
            trials_4.addData('byst_resp_ext.keys',byst_resp_ext.keys)
            if byst_resp_ext.keys != None:  # we had a response
                trials_4.addData('byst_resp_ext.rt', byst_resp_ext.rt)
                trials_4.addData('byst_resp_ext.duration', byst_resp_ext.duration)
            # check responses
            if byst_earlyresp_ext.keys in ['', [], None]:  # No response was made
                byst_earlyresp_ext.keys = None
            trials_4.addData('byst_earlyresp_ext.keys',byst_earlyresp_ext.keys)
            if byst_earlyresp_ext.keys != None:  # we had a response
                trials_4.addData('byst_earlyresp_ext.rt', byst_earlyresp_ext.rt)
                trials_4.addData('byst_earlyresp_ext.duration', byst_earlyresp_ext.duration)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-5.500000)
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_ext=='RR' or trial_type_ext=='RS' or trial_type_ext=='SR' or trial_type_ext=='SS' or trial_type_ext=='FF') repeats of 'trials_4'
        
        
        # set up handler to look after randomisation of conditions etc
        arsl_rating_ext = data.TrialHandler(nReps=int(trial_type_ext=='ARSL'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='arsl_rating_ext')
        thisExp.addLoop(arsl_rating_ext)  # add the loop to the experiment
        thisArsl_rating_ext = arsl_rating_ext.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisArsl_rating_ext.rgb)
        if thisArsl_rating_ext != None:
            for paramName in thisArsl_rating_ext:
                globals()[paramName] = thisArsl_rating_ext[paramName]
        
        for thisArsl_rating_ext in arsl_rating_ext:
            currentLoop = arsl_rating_ext
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisArsl_rating_ext.rgb)
            if thisArsl_rating_ext != None:
                for paramName in thisArsl_rating_ext:
                    globals()[paramName] = thisArsl_rating_ext[paramName]
            
            # --- Prepare to start Routine "ARSL_ext" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('ARSL_ext.started', globalClock.getTime())
            text_arsl_2.setText('When you see this shape, \nhow TENSE / CALM do you feel? ')
            resp_arsl_ext.keys = []
            resp_arsl_ext.rt = []
            _resp_arsl_ext_allKeys = []
            CS_stim_5.setPos([0, 0])
            CS_stim_5.setImage(image_ext)
            # keep track of which components have finished
            ARSL_extComponents = [text_arsl_2, SAM_arsl_2, resp_arsl_ext, CS_stim_5]
            for thisComponent in ARSL_extComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "ARSL_ext" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_arsl_2* updates
                
                # if text_arsl_2 is starting this frame...
                if text_arsl_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    text_arsl_2.frameNStart = frameN  # exact frame index
                    text_arsl_2.tStart = t  # local t and not account for scr refresh
                    text_arsl_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_arsl_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_arsl_2.started')
                    # update status
                    text_arsl_2.status = STARTED
                    text_arsl_2.setAutoDraw(True)
                
                # if text_arsl_2 is active this frame...
                if text_arsl_2.status == STARTED:
                    # update params
                    pass
                
                # *SAM_arsl_2* updates
                
                # if SAM_arsl_2 is starting this frame...
                if SAM_arsl_2.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    SAM_arsl_2.frameNStart = frameN  # exact frame index
                    SAM_arsl_2.tStart = t  # local t and not account for scr refresh
                    SAM_arsl_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(SAM_arsl_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'SAM_arsl_2.started')
                    # update status
                    SAM_arsl_2.status = STARTED
                    SAM_arsl_2.setAutoDraw(True)
                
                # if SAM_arsl_2 is active this frame...
                if SAM_arsl_2.status == STARTED:
                    # update params
                    pass
                
                # *resp_arsl_ext* updates
                waitOnFlip = False
                
                # if resp_arsl_ext is starting this frame...
                if resp_arsl_ext.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                    # keep track of start time/frame for later
                    resp_arsl_ext.frameNStart = frameN  # exact frame index
                    resp_arsl_ext.tStart = t  # local t and not account for scr refresh
                    resp_arsl_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(resp_arsl_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp_arsl_ext.started')
                    # update status
                    resp_arsl_ext.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(resp_arsl_ext.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(resp_arsl_ext.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if resp_arsl_ext.status == STARTED and not waitOnFlip:
                    theseKeys = resp_arsl_ext.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                    _resp_arsl_ext_allKeys.extend(theseKeys)
                    if len(_resp_arsl_ext_allKeys):
                        resp_arsl_ext.keys = _resp_arsl_ext_allKeys[-1].name  # just the last key pressed
                        resp_arsl_ext.rt = _resp_arsl_ext_allKeys[-1].rt
                        resp_arsl_ext.duration = _resp_arsl_ext_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *CS_stim_5* updates
                
                # if CS_stim_5 is starting this frame...
                if CS_stim_5.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_5.frameNStart = frameN  # exact frame index
                    CS_stim_5.tStart = t  # local t and not account for scr refresh
                    CS_stim_5.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_5, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_5.started')
                    # update status
                    CS_stim_5.status = STARTED
                    CS_stim_5.setAutoDraw(True)
                
                # if CS_stim_5 is active this frame...
                if CS_stim_5.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in ARSL_extComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "ARSL_ext" ---
            for thisComponent in ARSL_extComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('ARSL_ext.stopped', globalClock.getTime())
            # check responses
            if resp_arsl_ext.keys in ['', [], None]:  # No response was made
                resp_arsl_ext.keys = None
            arsl_rating_ext.addData('resp_arsl_ext.keys',resp_arsl_ext.keys)
            if resp_arsl_ext.keys != None:  # we had a response
                arsl_rating_ext.addData('resp_arsl_ext.rt', resp_arsl_ext.rt)
                arsl_rating_ext.addData('resp_arsl_ext.duration', resp_arsl_ext.duration)
            # the Routine "ARSL_ext" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_ext=='ARSL') repeats of 'arsl_rating_ext'
        
        
        # set up handler to look after randomisation of conditions etc
        exp_rating_ext = data.TrialHandler(nReps=int(trial_type_ext=='EXP'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='exp_rating_ext')
        thisExp.addLoop(exp_rating_ext)  # add the loop to the experiment
        thisExp_rating_ext = exp_rating_ext.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisExp_rating_ext.rgb)
        if thisExp_rating_ext != None:
            for paramName in thisExp_rating_ext:
                globals()[paramName] = thisExp_rating_ext[paramName]
        
        for thisExp_rating_ext in exp_rating_ext:
            currentLoop = exp_rating_ext
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisExp_rating_ext.rgb)
            if thisExp_rating_ext != None:
                for paramName in thisExp_rating_ext:
                    globals()[paramName] = thisExp_rating_ext[paramName]
            
            # --- Prepare to start Routine "EXP_ext" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('EXP_ext.started', globalClock.getTime())
            expect_txt_2.setText('When you see this shape, \ndo you EXPECT an electric shock? ')
            slider.reset()
            exp_resp_ext.keys = []
            exp_resp_ext.rt = []
            _exp_resp_ext_allKeys = []
            CS_stim_8.setPos([0, 0])
            CS_stim_8.setImage(image_ext)
            # keep track of which components have finished
            EXP_extComponents = [expect_txt_2, slider, exp_resp_ext, expect_rating_2, CS_stim_8]
            for thisComponent in EXP_extComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "EXP_ext" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *expect_txt_2* updates
                
                # if expect_txt_2 is starting this frame...
                if expect_txt_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    expect_txt_2.frameNStart = frameN  # exact frame index
                    expect_txt_2.tStart = t  # local t and not account for scr refresh
                    expect_txt_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(expect_txt_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'expect_txt_2.started')
                    # update status
                    expect_txt_2.status = STARTED
                    expect_txt_2.setAutoDraw(True)
                
                # if expect_txt_2 is active this frame...
                if expect_txt_2.status == STARTED:
                    # update params
                    pass
                
                # *slider* updates
                
                # if slider is starting this frame...
                if slider.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    slider.frameNStart = frameN  # exact frame index
                    slider.tStart = t  # local t and not account for scr refresh
                    slider.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(slider, 'tStartRefresh')  # time at next scr refresh
                    # update status
                    slider.status = STARTED
                    slider.setAutoDraw(True)
                
                # if slider is active this frame...
                if slider.status == STARTED:
                    # update params
                    pass
                
                # *exp_resp_ext* updates
                waitOnFlip = False
                
                # if exp_resp_ext is starting this frame...
                if exp_resp_ext.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                    # keep track of start time/frame for later
                    exp_resp_ext.frameNStart = frameN  # exact frame index
                    exp_resp_ext.tStart = t  # local t and not account for scr refresh
                    exp_resp_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(exp_resp_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'exp_resp_ext.started')
                    # update status
                    exp_resp_ext.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(exp_resp_ext.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(exp_resp_ext.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if exp_resp_ext.status == STARTED and not waitOnFlip:
                    theseKeys = exp_resp_ext.getKeys(keyList=['1','2','3','4','5'], ignoreKeys=["escape"], waitRelease=False)
                    _exp_resp_ext_allKeys.extend(theseKeys)
                    if len(_exp_resp_ext_allKeys):
                        exp_resp_ext.keys = _exp_resp_ext_allKeys[-1].name  # just the last key pressed
                        exp_resp_ext.rt = _exp_resp_ext_allKeys[-1].rt
                        exp_resp_ext.duration = _exp_resp_ext_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *expect_rating_2* updates
                
                # if expect_rating_2 is starting this frame...
                if expect_rating_2.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    expect_rating_2.frameNStart = frameN  # exact frame index
                    expect_rating_2.tStart = t  # local t and not account for scr refresh
                    expect_rating_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(expect_rating_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'expect_rating_2.started')
                    # update status
                    expect_rating_2.status = STARTED
                    expect_rating_2.setAutoDraw(True)
                
                # if expect_rating_2 is active this frame...
                if expect_rating_2.status == STARTED:
                    # update params
                    pass
                
                # *CS_stim_8* updates
                
                # if CS_stim_8 is starting this frame...
                if CS_stim_8.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_8.frameNStart = frameN  # exact frame index
                    CS_stim_8.tStart = t  # local t and not account for scr refresh
                    CS_stim_8.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_8, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_8.started')
                    # update status
                    CS_stim_8.status = STARTED
                    CS_stim_8.setAutoDraw(True)
                
                # if CS_stim_8 is active this frame...
                if CS_stim_8.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in EXP_extComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "EXP_ext" ---
            for thisComponent in EXP_extComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('EXP_ext.stopped', globalClock.getTime())
            exp_rating_ext.addData('slider.response', slider.getRating())
            exp_rating_ext.addData('slider.history', slider.getHistory())
            # check responses
            if exp_resp_ext.keys in ['', [], None]:  # No response was made
                exp_resp_ext.keys = None
            exp_rating_ext.addData('exp_resp_ext.keys',exp_resp_ext.keys)
            if exp_resp_ext.keys != None:  # we had a response
                exp_rating_ext.addData('exp_resp_ext.rt', exp_resp_ext.rt)
                exp_rating_ext.addData('exp_resp_ext.duration', exp_resp_ext.duration)
            # the Routine "EXP_ext" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_ext=='EXP') repeats of 'exp_rating_ext'
        
        
        # set up handler to look after randomisation of conditions etc
        val_ratings_ext = data.TrialHandler(nReps=int(trial_type_ext=='VAL'), method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='val_ratings_ext')
        thisExp.addLoop(val_ratings_ext)  # add the loop to the experiment
        thisVal_ratings_ext = val_ratings_ext.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisVal_ratings_ext.rgb)
        if thisVal_ratings_ext != None:
            for paramName in thisVal_ratings_ext:
                globals()[paramName] = thisVal_ratings_ext[paramName]
        
        for thisVal_ratings_ext in val_ratings_ext:
            currentLoop = val_ratings_ext
            thisExp.timestampOnFlip(win, 'thisRow.t')
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    inputs=inputs, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisVal_ratings_ext.rgb)
            if thisVal_ratings_ext != None:
                for paramName in thisVal_ratings_ext:
                    globals()[paramName] = thisVal_ratings_ext[paramName]
            
            # --- Prepare to start Routine "VAL_ext" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('VAL_ext.started', globalClock.getTime())
            val_text_2.setText('When you see this shape, \nhow POSITIVE / NEGATIVE do you feel? ')
            resp__val_ext.keys = []
            resp__val_ext.rt = []
            _resp__val_ext_allKeys = []
            CS_stim_9.setPos([0, 0])
            CS_stim_9.setImage(image_ext)
            # keep track of which components have finished
            VAL_extComponents = [val_text_2, SAM_val_2, resp__val_ext, CS_stim_9]
            for thisComponent in VAL_extComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "VAL_ext" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *val_text_2* updates
                
                # if val_text_2 is starting this frame...
                if val_text_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    val_text_2.frameNStart = frameN  # exact frame index
                    val_text_2.tStart = t  # local t and not account for scr refresh
                    val_text_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(val_text_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'val_text_2.started')
                    # update status
                    val_text_2.status = STARTED
                    val_text_2.setAutoDraw(True)
                
                # if val_text_2 is active this frame...
                if val_text_2.status == STARTED:
                    # update params
                    pass
                
                # *SAM_val_2* updates
                
                # if SAM_val_2 is starting this frame...
                if SAM_val_2.status == NOT_STARTED and tThisFlip >= 2.5-frameTolerance:
                    # keep track of start time/frame for later
                    SAM_val_2.frameNStart = frameN  # exact frame index
                    SAM_val_2.tStart = t  # local t and not account for scr refresh
                    SAM_val_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(SAM_val_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'SAM_val_2.started')
                    # update status
                    SAM_val_2.status = STARTED
                    SAM_val_2.setAutoDraw(True)
                
                # if SAM_val_2 is active this frame...
                if SAM_val_2.status == STARTED:
                    # update params
                    pass
                
                # *resp__val_ext* updates
                waitOnFlip = False
                
                # if resp__val_ext is starting this frame...
                if resp__val_ext.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                    # keep track of start time/frame for later
                    resp__val_ext.frameNStart = frameN  # exact frame index
                    resp__val_ext.tStart = t  # local t and not account for scr refresh
                    resp__val_ext.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(resp__val_ext, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'resp__val_ext.started')
                    # update status
                    resp__val_ext.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(resp__val_ext.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(resp__val_ext.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if resp__val_ext.status == STARTED and not waitOnFlip:
                    theseKeys = resp__val_ext.getKeys(keyList=['1','2','3','4','5','6','7','8','9'], ignoreKeys=["escape"], waitRelease=False)
                    _resp__val_ext_allKeys.extend(theseKeys)
                    if len(_resp__val_ext_allKeys):
                        resp__val_ext.keys = _resp__val_ext_allKeys[-1].name  # just the last key pressed
                        resp__val_ext.rt = _resp__val_ext_allKeys[-1].rt
                        resp__val_ext.duration = _resp__val_ext_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *CS_stim_9* updates
                
                # if CS_stim_9 is starting this frame...
                if CS_stim_9.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                    # keep track of start time/frame for later
                    CS_stim_9.frameNStart = frameN  # exact frame index
                    CS_stim_9.tStart = t  # local t and not account for scr refresh
                    CS_stim_9.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(CS_stim_9, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'CS_stim_9.started')
                    # update status
                    CS_stim_9.status = STARTED
                    CS_stim_9.setAutoDraw(True)
                
                # if CS_stim_9 is active this frame...
                if CS_stim_9.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, inputs=inputs, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in VAL_extComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "VAL_ext" ---
            for thisComponent in VAL_extComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('VAL_ext.stopped', globalClock.getTime())
            # check responses
            if resp__val_ext.keys in ['', [], None]:  # No response was made
                resp__val_ext.keys = None
            val_ratings_ext.addData('resp__val_ext.keys',resp__val_ext.keys)
            if resp__val_ext.keys != None:  # we had a response
                val_ratings_ext.addData('resp__val_ext.rt', resp__val_ext.rt)
                val_ratings_ext.addData('resp__val_ext.duration', resp__val_ext.duration)
            # the Routine "VAL_ext" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed int(trial_type_ext=='VAL') repeats of 'val_ratings_ext'
        
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'Extinction'
    
    
    # --- Prepare to start Routine "CONT_CHECK" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('CONT_CHECK.started', globalClock.getTime())
    cont_resp.keys = []
    cont_resp.rt = []
    _cont_resp_allKeys = []
    # keep track of which components have finished
    CONT_CHECKComponents = [text, cont_resp]
    for thisComponent in CONT_CHECKComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "CONT_CHECK" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        
        # if text is starting this frame...
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text.started')
            # update status
            text.status = STARTED
            text.setAutoDraw(True)
        
        # if text is active this frame...
        if text.status == STARTED:
            # update params
            pass
        
        # *cont_resp* updates
        waitOnFlip = False
        
        # if cont_resp is starting this frame...
        if cont_resp.status == NOT_STARTED and tThisFlip >= 2-frameTolerance:
            # keep track of start time/frame for later
            cont_resp.frameNStart = frameN  # exact frame index
            cont_resp.tStart = t  # local t and not account for scr refresh
            cont_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cont_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'cont_resp.started')
            # update status
            cont_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(cont_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(cont_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if cont_resp.status == STARTED and not waitOnFlip:
            theseKeys = cont_resp.getKeys(keyList=['s','c','n'], ignoreKeys=["escape"], waitRelease=False)
            _cont_resp_allKeys.extend(theseKeys)
            if len(_cont_resp_allKeys):
                cont_resp.keys = _cont_resp_allKeys[-1].name  # just the last key pressed
                cont_resp.rt = _cont_resp_allKeys[-1].rt
                cont_resp.duration = _cont_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in CONT_CHECKComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "CONT_CHECK" ---
    for thisComponent in CONT_CHECKComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('CONT_CHECK.stopped', globalClock.getTime())
    # check responses
    if cont_resp.keys in ['', [], None]:  # No response was made
        cont_resp.keys = None
    thisExp.addData('cont_resp.keys',cont_resp.keys)
    if cont_resp.keys != None:  # we had a response
        thisExp.addData('cont_resp.rt', cont_resp.rt)
        thisExp.addData('cont_resp.duration', cont_resp.duration)
    thisExp.nextEntry()
    # the Routine "CONT_CHECK" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "INSTR" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('INSTR.started', globalClock.getTime())
    ok1.keys = []
    ok1.rt = []
    _ok1_allKeys = []
    # keep track of which components have finished
    INSTRComponents = [ok1, instruct1]
    for thisComponent in INSTRComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "INSTR" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ok1* updates
        waitOnFlip = False
        
        # if ok1 is starting this frame...
        if ok1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ok1.frameNStart = frameN  # exact frame index
            ok1.tStart = t  # local t and not account for scr refresh
            ok1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ok1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ok1.started')
            # update status
            ok1.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ok1.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ok1.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ok1.status == STARTED and not waitOnFlip:
            theseKeys = ok1.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _ok1_allKeys.extend(theseKeys)
            if len(_ok1_allKeys):
                ok1.keys = _ok1_allKeys[-1].name  # just the last key pressed
                ok1.rt = _ok1_allKeys[-1].rt
                ok1.duration = _ok1_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        # Run 'Each Frame' code from code
        your_mouse = event.Mouse(visible = False)
        
        # *instruct1* updates
        
        # if instruct1 is starting this frame...
        if instruct1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct1.frameNStart = frameN  # exact frame index
            instruct1.tStart = t  # local t and not account for scr refresh
            instruct1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct1.started')
            # update status
            instruct1.status = STARTED
            instruct1.setAutoDraw(True)
        
        # if instruct1 is active this frame...
        if instruct1.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, inputs=inputs, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in INSTRComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "INSTR" ---
    for thisComponent in INSTRComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('INSTR.stopped', globalClock.getTime())
    # check responses
    if ok1.keys in ['', [], None]:  # No response was made
        ok1.keys = None
    thisExp.addData('ok1.keys',ok1.keys)
    if ok1.keys != None:  # we had a response
        thisExp.addData('ok1.rt', ok1.rt)
        thisExp.addData('ok1.duration', ok1.duration)
    thisExp.nextEntry()
    # the Routine "INSTR" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    # Run 'End Experiment' code from code
    your_mouse = event.Mouse(visible = True)
    # Run 'End Experiment' code from code
    your_mouse = event.Mouse(visible = True)
    
    # mark experiment as finished
    endExperiment(thisExp, win=win, inputs=inputs)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, inputs=None, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    inputs : dict
        Dictionary of input devices by name.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if inputs is not None:
        if 'eyetracker' in inputs and inputs['eyetracker'] is not None:
            inputs['eyetracker'].setConnectionState(False)
    logging.flush()


def quit(thisExp, win=None, inputs=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    inputs : dict
        Dictionary of input devices by name.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    if inputs is not None:
        if 'eyetracker' in inputs and inputs['eyetracker'] is not None:
            inputs['eyetracker'].setConnectionState(False)
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    inputs = setupInputs(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win, 
        inputs=inputs
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win, inputs=inputs)
